---
name: review-design
description: Judge the visual design and usability of a Unity tool or other productivity UI using actual rendered screens, task evidence, and project design references.
---

# Review Design

Read the [shared handoff](../review/references/handoff.md). Identify the user, frequent task, main decision, supported window sizes and themes, and agreed visual reference. Prefer the project's design system or approved comparisons. If absent, use surrounding screens and applicable [Unity Editor Foundations](https://www.foundations.unity.com/) guidance as review references. State the assumptions. A mockup can support proposal critique. Implemented UI claims require renders from the reviewed implementation.

Inspect actual captures and, when available, the input transcript. For a redesign compare before and after with the same data, window, scale, and theme. Choose cases that could disprove the intended quality, such as a narrow docked panel, long labels, dense data, empty/error states, or progress and cancellation. Reuse the workflow stage's artifacts if they cover those cases. A reviewer needs to actually view each image it judges.

| Lens | Evidence to look for |
| --- | --- |
| Visual hierarchy and aesthetics | Main action is recognizable, related controls are grouped, alignment and spacing are consistent, and typography, color, and density suit the task. Identify concrete deviations from the reference or patterns that make the design harder to scan. |
| Task flow | Trace the frequent task. Check control discovery, action order, terminology, visible feedback, and ability to recover. For improvement claims compare actions, time, or errors on the same scenario where possible. |
| Layout and accessibility | Check clipping, overlap, label readability, focus visibility, and communication beyond color. Use actual supported configurations. |
| States | Check relevant empty, busy, disabled, invalid, failure, and success states. Show whether each explains what happened and what the user can do next. |

Run the project's deterministic screenshot or geometry checks if present and applicable. Pixel comparisons can flag visual changes for inspection. They do not decide visual quality. Keyboard reachability and focus behavior require interaction evidence. Quantified targets need an agreed threshold and a suitable measurement.

Return specific findings with screenshot and location, affected task, severity, and a suggested adjustment. Distinguish observable defects, design judgments, and preferences. State a reasoned verdict on the agreed criteria, including what works. Keep required aesthetic approval or evidence from actual users open if it has not happened. Do not present a taste score as a measured outcome.
