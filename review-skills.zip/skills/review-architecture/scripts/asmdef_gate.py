#!/usr/bin/env python3
"""Check explicit, direct Unity assembly-reference rules across selected roots."""

import argparse
from fnmatch import fnmatchcase
import json
from pathlib import Path
import re


def collect(roots):
    files = set()
    for root in roots:
        if root.is_file() and root.suffix == ".asmdef":
            files.add(root.resolve())
        elif root.is_dir():
            files.update(path.resolve() for path in root.rglob("*.asmdef") if path.is_file())
        else:
            raise ValueError(f"Missing assembly or root: {root}")
    assemblies = {}
    guid_to_name = {}
    for file in sorted(files):
        record = json.loads(file.read_text(encoding="utf-8-sig"))
        if not isinstance(record, dict):
            raise ValueError(f"Expected JSON object: {file}")
        name, references = record.get("name"), record.get("references", [])
        if not isinstance(name, str) or not name.strip() or not isinstance(references, list):
            raise ValueError(f"Invalid assembly definition: {file}")
        if any(not isinstance(ref, str) or not ref.strip() for ref in references):
            raise ValueError(f"Invalid assembly reference: {file}")
        if name in assemblies:
            raise ValueError(f"Duplicate assembly name {name}: {file}")
        assemblies[name] = (file, references)
        meta = file.with_name(file.name + ".meta")
        if meta.is_file():
            match = re.search(r"^guid:\s*([a-fA-F0-9]{32})\s*$", meta.read_text(encoding="utf-8-sig"), re.M)
            if match:
                guid = match[1].lower()
                if guid in guid_to_name:
                    raise ValueError(f"Duplicate assembly GUID {guid}: {file}")
                guid_to_name[guid] = name
    return assemblies, guid_to_name


def evaluate(assemblies, guid_to_name, rules):
    violations, unresolved, unmatched = [], [], []
    for source_pattern, target_pattern in rules:
        sources = [name for name in assemblies if fnmatchcase(name, source_pattern)]
        if not sources:
            unmatched.append(source_pattern)
        for source in sorted(sources):
            file, references = assemblies[source]
            for reference in references:
                target = reference
                if reference.startswith("GUID:"):
                    target = guid_to_name.get(reference[5:].lower())
                edge = {"source": source, "path": str(file), "reference": reference,
                        "target": target, "rule": [source_pattern, target_pattern]}
                if target is None:
                    unresolved.append(edge)
                elif fnmatchcase(target, target_pattern):
                    violations.append(edge)
    status = "FAIL" if violations else "BLOCKED" if unresolved or unmatched else "PASS"
    return {
        "status": status,
        "assembly_count": len(assemblies),
        "unmatched_source_patterns": sorted(set(unmatched)),
        "unresolved_guids": unresolved,
        "violations": violations,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True, action="append", help="directory or .asmdef file; repeat as needed")
    parser.add_argument("--forbid", nargs=2, action="append", required=True,
                        metavar=("SOURCE_GLOB", "TARGET_GLOB"))
    args = parser.parse_args()
    try:
        result = evaluate(*collect(args.root), args.forbid)
    except (OSError, ValueError) as error:
        result = {"status": "BLOCKED", "reason": str(error)}
    print(json.dumps(result, indent=2))
    return {"PASS": 0, "FAIL": 1, "BLOCKED": 2}[result["status"]]


if __name__ == "__main__":
    raise SystemExit(main())
