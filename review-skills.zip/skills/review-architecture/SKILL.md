---
name: review-architecture
description: Assess the architecture of a Unity or C# tool change or redesign. Review state ownership, dependency direction, testability, migration, and the cost of a real future change. Enforce explicit assembly rules with a script where applicable.
---

# Review Architecture

Read the [shared handoff](../review/references/handoff.md). Start with the design problem and project constraints. Treat architectural quality as a judgment about specified changes and failure modes. A framework name or passing tests provide limited evidence about those tradeoffs.

1. Trace one or two representative operations from entry to policy, state mutation, external effects, and readback. Name who owns state, who may write it, who performs undo/persistence, and who releases resources and subscriptions. Look for duplicate sources of truth, accidental global state, behavior tied to window lifecycle, and dependencies that require unrelated modules to change together.
2. Check the project's architectural rules. If a rule prohibits an explicit Unity assembly dependency, use [asmdef_gate.py](scripts/asmdef_gate.py) with the actual rule and relevant project/package roots. Its direct-reference report complements inspection of runtime dependencies, implicit references, and state ownership. For other machine-checkable rules, run the project's existing scripts or architecture tests.
3. Compare designs against real change scenarios. For example, trace how adding a second authoring entry point or changing validation propagates. Compare required callers, state owners, edits, test setup, and lifecycle risks before and after. Ground claims in current code, an actual spike, or clearly identified predictions. A small public operation that owns substantial behavior can be easier to change than many thin layers. Require a specific responsibility or substitution need for extra abstraction.
4. For a redesign, check preservation of required behavior, old saved assets/configurations, caller migration, and rollback where relevant. Use old fixtures and run existing behavior checks through the new path. Measure relevant performance claims against the same workload. Mark unexecuted migration or performance checks open. For a proposal, report design findings and separately label implementation evidence that remains pending.

Report material rule violations or risks with a concrete failing scenario and evidence. Explain the smallest design change that resolves each one and why. Distinguish enforceable rules, evidence-backed design judgments, and preferences. A severity or change-cost comparison can aid the decision. A universal architecture score cannot.

## Explicit assembly rule example

Run this only when the real project forbids direct dependencies from the matching source assemblies to the matching target assemblies. Quote glob patterns and pass extra roots for resolved packages as needed.

~~~bash
python3 "/path/to/review-architecture/scripts/asmdef_gate.py" \
  --root "/path/to/project/Assets" --root "/path/to/project/Packages" \
  --forbid 'Game.Runtime*' 'Game.Editor*'
~~~

The report includes explicit edges, unresolved GUIDs, and unmatched source patterns. Exit 0 means the supplied rule passed in the scanned graph. Exit 1 means a violation was found. Exit 2 means it could not be decided. The script resolves name references and GUIDs using .asmdef.meta files in scanned roots. It does not model transitive, platform-conditioned, implicit, or runtime dependencies. Inspect those separately when material.
