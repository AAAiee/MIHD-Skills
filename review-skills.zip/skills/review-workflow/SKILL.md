---
name: review-workflow
description: Verify a Unity or C# tool against its requirements through the real production workflow. Use editor input, MCP or other probes, and read-only checks of outputs, persistence, and recovery.
---

# Review Workflow

Read the [shared handoff](../review/references/handoff.md). Start from the requested outcome and compare it against the candidate's exposed behavior. Identify changed entry points and material unintended effects. Confirm project identity, ready state, candidate revision, and harness capabilities before acting. Use [editor driving](references/editor-driving.md) when Unity is involved.

Exercise the normal path with disposable fixtures. Record preconditions, actual input or invocation, expected result, resulting state, and relevant logs. Use APIs freely to prepare fixtures and read results. Label any API that performs the tested action as an API-level check. Reuse an existing scripted journey where it exercises the required path. If the probe only calls C# or executes a menu command, verify the command behavior and keep mouse, keyboard, focus, or discoverability claims open.

Check durable effects by observing their real owner. Reload an asset or document and examine its values and references. For irreversible or destructive operations, use authorized disposable inputs. Assert what changed and what stayed intact. Test a materially different adverse path when relevant, such as cancel, partial failure, repeated use, wrong selection, or lost service connection. For recovery claims, actually restore known data into a safe target and check contents, metadata/references, and subsequent use. A created backup file is evidence of creation only.

Use a bounded wait for actual completion. Probe setup must not save, mark dirty, record Undo, or update preferences on behalf of the production operation under review. Assert Undo and Redo end states where promised. Capture relevant before/after renders and states for the design reviewer. A screen image alone does not record what input produced it.

If the required path cannot be driven, report the missing capability and a short manual scenario with expected observations. Clean up owned fixtures, retain evidence, and report any state you could not restore.
