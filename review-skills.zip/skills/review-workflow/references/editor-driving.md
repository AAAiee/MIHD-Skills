# Driving and observing Unity

Read before a live editor journey. Bind to the project's actual harness; no MCP commands are assumed here.

## Trust the session before driving

Confirm project path/version, active instance, compilation/import completion, current mode, and that the editor loaded the code being verified. Recheck after recompilation, reconnects, reloads, or surprising failures. A working transport can connect to the wrong or unusable editor.

Read tool schemas and project recipes. Establish capabilities for window inspection, event dispatch, pointer/keyboard input, menu commands, C# methods, asset saving, log reading, and test execution. Record exact supported calls in the project record. Unclear implementation cannot support stronger interaction claims.

Use disposable fixtures/copies for destructive/reload cases. Preserve original selection, scene setup, relevant settings, and unsaved work where restoration is safe. One live driver owns an editor session; isolate or serialize tests touching global editor state.

## Preserve the tested action

| Mechanism | Supports | Does not automatically support |
| --- | --- | --- |
| Direct production C# command | Operation with those dependencies | Button wiring, discoverability, focus, hit testing |
| Programmatic menu execution | Command registration/execution | Visible menu, enabled-state presentation, input access |
| Set `SerializedProperty` | The tested applied serialization/binding path | Typing, validation timing, focus, drag/drop, user commit |
| Callback invocation or event dispatch | The callback/event path exercised | Native input, hit testing, occlusion, disabled/focus behavior |
| Input into an actual control | Recorded input workflow and result | Untested input methods, platforms/layouts, persistence |
| State read or screenshot | Observed state at that moment | Causation, persistence, or absence of errors elsewhere |

API setup is allowed, but must not perform the action or produce the outcome being tested. Use fixtures whose starting values differ from expected results and unaffected sentinels when unintended edits are plausible.

Prefer stable identities/names/hierarchy and supported input mechanisms. Before using coordinates capture actual layout, size, scale, focus, and target. Do not replay stale coordinates or assume UI Toolkit, IMGUI, Scene view, and native dialogs have interchangeable support.

Wait on meaningful completion states with deadlines. Fixed sleeps are not proof. On timeout capture state/logs, diagnose, and rerun only after a concrete readiness/harness correction; do not retry indefinitely until a pass appears.

## Keep a causal record

For each journey record:

1. Preconditions: fixture contents/identity, selection, scene/window, mode, initial persisted state.
2. Action: entry path and exact driver calls/input transcript.
3. Expected/observed: visible feedback, exact state/values, affected scope, errors, required non-effects.
4. Evidence: before/after UI captures when appearance matters, structured state, relevant log interval, saved/reloaded results for persistence.
5. Cleanup: owned fixtures/processes removed/restored, evidence retained.

Use read-only observations independent of the operation's success report. Do not compute actual and expected values through the same production helper. Reading documented saved fields or loading generated assets through Unity legitimately observes external effects; inspecting private caches usually does not.

## Unity-specific traps

- **Dirty versus saved:** dirty flags, in-memory values, and success toasts do not prove durable persistence. Conversely, forcing `EditorSceneManager.SaveScene` can save a non-dirty scene and conceal missing dirty bookkeeping. Check required production bookkeeping separately, then the documented save action and a true reload/reacquisition. Refresh is not automatically a disk reload. Never mark dirty or force-save to repair the result while observing it.
- **Undo:** verify real registration/grouping and expected undo steps, including created/deleted objects where relevant. Assert values after Undo/Redo. `Undo.RecordObject` has deferred diff behavior and does not cover all structural operations; use the installed version's dedicated APIs as appropriate. Do not repair missing registration in the test.
- **Prefabs:** instance changes may need override recording and must not unintentionally mutate the source. Verify actual overrides and reopen results. Apply/revert, nested, and variant cases depend on supported scope.
- **References:** check loaded saved content, reference/GUID retention, unchanged fields, and input/output ownership. File existence alone is weak evidence.
- **Lifecycle:** static state, event subscriptions, stale references, window reconstruction, and domain/scene reload settings can change behavior. Exercise promised transitions and repeated use, not every imaginable setting.
- **Logs:** capture the relevant interval with a baseline. Investigate unexpected exceptions/assertions/errors; classify warnings by impact. Negative-path errors need specific expectations. Do not globally suppress logs or clear user diagnostics to obtain a clean screen.
- **Performance/appearance:** speed claims need workload and budget; clipping/focus/feedback claims need rendered evidence. Artistic quality or pleasantness may require the intended user's judgment.

Without input automation, deliver available integration evidence and a concise manual journey with expected observations. The journey remains blocked until performed; attribute user-provided evidence. Do not redefine a UI criterion as an API criterion.
