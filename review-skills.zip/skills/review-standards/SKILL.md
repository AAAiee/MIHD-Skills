---
name: review-standards
description: Check C# and Unity changes against project code standards. Execute configured formatters, analyzers, and comment checks in read-only mode, then inspect rules automation cannot judge.
---

# Review Standards

Read the [shared handoff](../review/references/handoff.md). Find applicable project guidance, style configuration, CI, analyzer rules, and comment policy. Record which rules apply to the changed source, including generated files and existing exceptions. The project owns the policy.

1. Run existing read-only format, static analysis, and comment checks with their normal project inputs. Use [run_check.py](../review/scripts/run_check.py) to capture a named command, bounded execution, logs, and its exit status in a fresh directory. Run Unity compilation or consume its fresh results when assembly definitions or Unity APIs are relevant. Verify the tools actually loaded the expected configuration and processed the intended files. Inspect diagnostics even when the command exits successfully if its exit convention permits warnings or finding output.
2. For judgment-only rules, review the changed code and necessary context. Look for stale or misleading comments, repeated narration, unclear names, disabled warnings, and exceptions hidden by broad suppressions. For each issue cite the rule or state the concrete maintenance consequence. Keep comments that explain a relevant external constraint, a non-obvious reason, or a required contract unless the project says otherwise. Prefer an existing syntax-aware rule for comment syntax. Searching for slash pairs can match strings and URLs.
3. Report which checks ran, which files they covered, and observed rule violations. Separate new issues from baseline debt. A missing mandatory check blocks that claim. If no policy/tool exists, record the manual review scope and offer repeatable rules only for a concrete recurring need. Do not introduce a formatter, delete comments, or fix suppressions during a review.

## Capture a configured command

Use Python 3.9 or newer. Supply the exact documented check in place of the sample executable and flags.

~~~bash
python3 "/path/to/review/scripts/run_check.py" \
  --cwd "/path/to/project" --out "/path/to/feature/review/standards" --timeout 300 -- \
  project-style-check --verify
~~~

The output contains the fresh evidence directory and process status. A successful process exit establishes only that command's reported result. Use the recorded output to check the documented diagnostic policy. Keep credentials out of command arguments and retained evidence.
