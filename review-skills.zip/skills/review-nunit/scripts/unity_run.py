"""Unity batch command construction, project ownership, and startup diagnostics."""

from contextlib import contextmanager
import errno
import hashlib
import os
from pathlib import Path
import re
import tempfile


class ProjectBusy(Exception):
    pass


def project_root(path):
    project = path.resolve()
    if not (project / "Assets").is_dir() or not (project / "ProjectSettings/ProjectVersion.txt").is_file():
        raise ValueError(f"Not a Unity project: {project}")
    return project


@contextmanager
def project_lease(project, allow_stale_marker=False):
    # Keep the lock outside Unity's Temp directory, which Unity can remove.
    # Keep the file itself after closing it so contenders always lock one inode.
    info = project.stat()
    identity = f"{info.st_dev}:{info.st_ino}" if info.st_ino else os.path.normcase(str(project))
    key = hashlib.sha256(identity.encode()).hexdigest()
    directory = Path(tempfile.gettempdir()) / "codex-unity-test-locks"
    directory.mkdir(mode=0o700, exist_ok=True)
    lock_path = directory / key
    with lock_path.open("a+b") as lock:
        try:
            if os.name == "nt":
                import msvcrt
                lock.seek(0)
                msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as error:
            if error.errno in (errno.EACCES, errno.EAGAIN):
                raise ProjectBusy(f"Another test runner owns {project}.") from error
            raise
        if not allow_stale_marker and (project / "Temp/UnityLockfile").exists():
            raise ProjectBusy(
                f"Unity lock marker present in {project}. Check the editor owner or use an isolated copy."
            )
        yield lock_path.with_suffix(".coplay-pending.json")


def exact_filter(names):
    def escape(name):
        # Unity also treats semicolons as list separators.
        return re.escape(name).replace(";", r"\x3b")

    return r"\A(?:" + "|".join(escape(name) for name in sorted(names)) + r")\z"


def unity_command(args, project, expected):
    command = [
        str(args.editor.resolve()), "-batchmode", "-projectPath", str(project),
        "-runTests", "-testPlatform", args.test_platform,
        "-testResults", "{xml}", "-logFile", "{log}",
    ]
    if expected:
        command.extend(["-testFilter", exact_filter(expected)])
    if args.nographics:
        command.append("-nographics")
    return command


def project_argument(command, cwd):
    for index, arg in enumerate(command):
        name, equals, value = arg.partition("=")
        if name.lower() == "-projectpath":
            if not equals:
                if index + 1 == len(command):
                    raise ValueError("-projectPath has no value")
                value = command[index + 1]
            return project_root(cwd / value)
    return None


def diagnose_startup(paths):
    for path in paths:
        try:
            with path.open("rb") as log:
                log.seek(max(0, path.stat().st_size - 16384))
                tail = log.read(16384).lower()
        except FileNotFoundError:
            continue
        if (b"another unity instance is running with this project open" in tail
                or b"multiple unity instances cannot open the same project" in tail):
            return {"status": "PROJECT_BUSY", "detail": "Unity reports the project is already open."}
        if b"aborting batchmode due to failure" in tail:
            return {"status": "UNITY_ABORT", "detail": f"Unity reported a batch-mode abort. See {path.name}."}
    return None
