"""One bounded-worker request to Coplay's local HTTP CLI API."""

from http.client import HTTPConnection, HTTPException
import json
import sys


def main():
    port, budget, route, payload = sys.argv[1:]
    connection = HTTPConnection("127.0.0.1", int(port), timeout=float(budget))
    try:
        if payload:
            connection.request("POST", route, payload.encode(), {"Content-Type": "application/json"})
        else:
            connection.request("GET", route)
        response = connection.getresponse()
        body = response.read(16 * 1024 * 1024 + 1)
        if len(body) > 16 * 1024 * 1024:
            raise ValueError("Coplay response exceeded 16 MiB")
        try:
            result = json.loads(body)
        except (UnicodeError, ValueError):
            result = None
        print(json.dumps({"http_status": response.status, "body": result}))
    except (OSError, HTTPException, ValueError) as error:
        print(json.dumps({"error": f"{type(error).__name__}: {error}"}))
    finally:
        connection.close()


if __name__ == "__main__":
    main()
