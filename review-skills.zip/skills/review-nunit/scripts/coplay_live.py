"""Bounded test jobs in a single Editor connected to Coplay 10.3 local HTTP."""

from collections import Counter
import json
import os
from pathlib import Path
import sys
import time

from run_check import execute, new_run, write_json
from unity_run import ProjectBusy, project_lease, project_root


class Blocked(Exception):
    def __init__(self, code, reason, *, transition=False):
        super().__init__(reason)
        self.code = code
        self.transition = transition


def object_value(value):
    return value if isinstance(value, dict) else {}


def add_arguments(parser):
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--instance", help="full Coplay instance hash if more than one Editor is connected")
    parser.add_argument("--test-platform", choices=("EditMode", "PlayMode"), default="EditMode")
    parser.add_argument("--exclusive", action="store_true", help="the coordinator has reserved the live Editor")
    parser.add_argument("--probe-only", action="store_true", help="check the live Editor without starting tests")
    parser.add_argument("--wait-ready", action="store_true",
                        help="with an exclusive probe, watch an observed compile, reload, or import")
    parser.add_argument("--confirm-idle", action="store_true",
                        help="with --probe-only, reconcile after independently checking no test is active or queued")
    parser.add_argument("--rpc-timeout", type=float, default=3, help="seconds per HTTP request")
    parser.add_argument("--startup-timeout", type=float, help="time to first test start in seconds")
    parser.add_argument("--stall-timeout", type=float, default=30, help="seconds without test progress")
    parser.add_argument("--timeout", type=float, default=300, help="overall deadline in seconds")


class LiveEditor:
    def __init__(self, args, project, run):
        self.args = args
        self.project = project
        self.run = run
        self.instance = None
        self.job = None
        self.progress = None
        self.deadline = time.monotonic() + args.timeout
        self.calls = 0

    def request(self, route, payload=None, *, deadline=None):
        cutoff = min(self.deadline, deadline) if deadline is not None else self.deadline
        budget = min(self.args.rpc_timeout, cutoff - time.monotonic())
        label = payload["type"] if payload else route
        if budget <= 0:
            raise Blocked("DEADLINE", f"Deadline reached before {label}.")
        self.calls += 1
        evidence = self.run / f"request-{self.calls:03d}"
        evidence.mkdir()
        worker = Path(__file__).with_name("coplay_http.py").resolve()
        command = [sys.executable, str(worker), str(self.args.port), str(budget), route,
                   json.dumps(payload) if payload else ""]
        process = execute(command, self.project, evidence, budget)
        if process["status"] == "TIMEOUT":
            raise Blocked("MCP_TIMEOUT", f"{label} did not respond within {budget:g}s.")
        if process["status"] != "COMPLETED" or process["exit_code"] != 0:
            raise Blocked("MCP_CLIENT_ERROR", f"HTTP worker ended during {label}: {process['status']}.")
        try:
            packet = json.loads((evidence / "stdout.log").read_text(encoding="utf-8"))
        except (OSError, ValueError) as error:
            raise Blocked("MCP_BAD_RESPONSE", f"Invalid response from {label}: {error}") from error
        if not isinstance(packet, dict):
            raise Blocked("MCP_BAD_RESPONSE", f"Invalid response from {label}.")
        if packet.get("error"):
            error = str(packet["error"])
            code = "MCP_TIMEOUT" if "TimeoutError" in error else "MCP_UNREACHABLE"
            raise Blocked(code, f"{label}: {error}")
        status, body = packet.get("http_status"), packet.get("body")
        if status != 200 or not isinstance(body, dict):
            detail = str(object_value(body).get("error", ""))
            missing_target = status == 404 and detail.startswith("Unity instance ") and detail.endswith("not found")
            code = "UNITY_DISCONNECTED" if status == 503 or missing_target else "MCP_HTTP_ERROR"
            raise Blocked(code, f"{label}: HTTP {status}. {detail}".strip())
        return body

    def command(self, name, params=None, *, deadline=None):
        response = self.request("/api/command", {
            "type": name, "params": params or {}, "unity_instance": self.instance,
        }, deadline=deadline)
        if response.get("success") is not True or not isinstance(response.get("data"), dict):
            detail = response.get("error") or response.get("message") or "Missing command data"
            raise Blocked("UNITY_COMMAND_ERROR", f"{name}: {detail}")
        return response["data"]

    def connect(self):
        if self.request("/health").get("status") != "healthy":
            raise Blocked("MCP_UNHEALTHY", "Coplay's HTTP health check did not report healthy.")
        instances = self.request("/api/instances").get("instances")
        if not isinstance(instances, list) or not instances:
            raise Blocked("UNITY_DISCONNECTED", "The MCP server is up, but no Unity Editor is connected.")
        candidates = [item["hash"] for item in instances if isinstance(item, dict)
                      and isinstance(item.get("hash"), str) and item["hash"]]
        if self.args.instance:
            candidates = [item for item in candidates if item == self.args.instance]
        if len(candidates) != 1:
            raise Blocked("INSTANCE_SELECTION", "Select one connected Editor using its full Coplay hash.")
        self.instance = candidates[0]
        info = self.command("get_project_info")
        actual = info.get("projectRoot")
        if not isinstance(actual, str) or not actual or Path(actual).resolve() != self.project:
            raise Blocked("WRONG_PROJECT", f"Connected Editor reports {actual!r}, expected {self.project}.")
        return info

    def check_state(self, *, deadline=None):
        state = self.command("get_editor_state", deadline=deadline)
        tests = object_value(state.get("tests"))
        phase = object_value(state.get("activity")).get("phase")
        play = object_value(object_value(state.get("editor")).get("play_mode"))
        compile_state = object_value(state.get("compilation"))
        assets = object_value(state.get("assets"))
        if tests.get("is_running") is not False or tests.get("current_job_id"):
            raise Blocked("EDITOR_TEST_BUSY", f"Editor has an active or uncertain test job: {tests.get('current_job_id')}.")
        if play.get("is_playing") is not False or play.get("is_changing") is not False:
            raise Blocked("EDITOR_BUSY", f"Editor is playing or changing modes: {phase!r}.")
        if (phase != "idle"
                or compile_state.get("is_compiling") is not False
                or compile_state.get("is_domain_reload_pending") is not False
                or assets.get("is_updating") is not False):
            raise Blocked("EDITOR_BUSY", f"Editor readiness does not permit a test start: {phase!r}.",
                          transition=phase in ("compiling", "domain_reload", "asset_import"))
        return state

    def check_idle(self, *, require_clean_scenes):
        # A live scene read exercises the dispatcher even when state is cached.
        scenes = self.command("manage_scene", {"action": "get_loaded_scenes"}).get("scenes")
        if not isinstance(scenes, list) or not scenes or any(not isinstance(scene, dict) for scene in scenes):
            raise Blocked("MCP_BAD_RESPONSE", "Editor returned no inspectable loaded scenes.")
        state = self.check_state()
        if require_clean_scenes:
            dirty = [str(scene.get("name") or scene.get("path") or "(unnamed)") for scene in scenes
                     if scene.get("isDirty") is not False]
            if dirty:
                raise Blocked("DIRTY_SCENES", f"Resolve unsaved scene changes before testing: {', '.join(dirty)}.")
        return state

    def wait_ready(self):
        observed_transition = False
        reconnect_deadline = None
        last_notice = float("-inf")
        while time.monotonic() < self.deadline:
            try:
                self.check_state(deadline=reconnect_deadline)
                return self.check_idle(require_clean_scenes=True)
            except Blocked as error:
                now = time.monotonic()
                reconnecting = False
                if error.transition:
                    observed_transition = True
                    reconnect_deadline = None
                elif observed_transition and error.code in {"MCP_TIMEOUT", "UNITY_DISCONNECTED"}:
                    if reconnect_deadline is None:
                        reconnect_deadline = min(self.deadline, now + 12)
                        reconnecting = True
                    if now >= reconnect_deadline:
                        raise
                else:
                    raise
                if reconnecting or now - last_notice >= 15:
                    print(f"Readiness: {error} ({max(0, self.deadline - now):.0f}s remaining)",
                          file=sys.stderr, flush=True)
                    last_notice = now
                cutoff = reconnect_deadline if reconnect_deadline is not None else self.deadline
                if cutoff - now <= 2:
                    raise Blocked("READINESS_TIMEOUT", f"Readiness deadline reached. Last observation: {error}") from error
                time.sleep(2)
        raise Blocked("READINESS_TIMEOUT", "The observed Editor transition did not settle before the deadline.")

    def poll(self, job, deadline=None):
        data = self.command("get_test_job", {"job_id": job, "includeDetails": True}, deadline=deadline)
        if data.get("job_id") != job:
            raise Blocked("JOB_ID_MISMATCH", "Coplay returned a result for a different job.")
        return data

    def wait(self, started, wall_started_ms, startup_timeout):
        last_change = started
        last_progress = None
        has_started = False
        retried_poll = False
        reported_failures = 0
        while True:
            cutoff = last_change + self.args.stall_timeout if has_started else started + startup_timeout
            now = time.monotonic()
            if now >= self.deadline:
                raise Blocked("RUN_DEADLINE", "Overall deadline elapsed with the test job still active.")
            if now >= cutoff:
                if self.progress and self.progress.get("editor_is_focused") is False:
                    raise Blocked("EDITOR_UNFOCUSED", "Test progress stopped while Unity was unfocused. Focus the same Editor and check the existing job.")
                code = "TEST_STALLED" if has_started else "TEST_START_TIMEOUT"
                raise Blocked(code, "No new Unity test progress within the configured budget.")
            try:
                data = self.poll(self.job, deadline=cutoff)
            except Blocked as error:
                if error.code not in {"MCP_TIMEOUT", "MCP_UNREACHABLE", "UNITY_DISCONNECTED"} or retried_poll:
                    raise
                if time.monotonic() >= min(cutoff, self.deadline):
                    continue
                retried_poll = True
                # One read-only recovery check, then resume polling the same job.
                if self.request("/health", deadline=cutoff).get("status") != "healthy":
                    raise
                print(f"Coplay connection interrupted. Checking existing job {self.job}.", file=sys.stderr, flush=True)
                continue
            stamp = data.get("started_unix_ms")
            if type(stamp) is not int or stamp < wall_started_ms - 5000 or stamp > time.time() * 1000 + 5000:
                raise Blocked("STALE_JOB", "Job start does not match this run's dispatch window.")
            if data.get("mode") != self.args.test_platform:
                raise Blocked("JOB_MODE_MISMATCH", "Job mode does not match the requested mode.")
            if data.get("status") in {"succeeded", "failed", "cancelled"}:
                return data
            if data.get("status") != "running":
                raise Blocked("MCP_BAD_RESPONSE", f"Unexpected job status {data.get('status')!r}.")
            self.progress = object_value(data.get("progress"))
            failures = self.progress.get("failures_so_far")
            if isinstance(failures, list) and len(failures) > reported_failures:
                reported_failures = len(failures)
                name = object_value(failures[-1]).get("full_name") or "an unnamed test"
                print(f"Unity reported a failure in {name}.", file=sys.stderr, flush=True)
            fields = ("total", "completed", "current_test_full_name", "current_test_started_unix_ms",
                      "last_finished_unix_ms")
            progress = tuple(self.progress.get(field) for field in fields)
            if progress != last_progress:
                has_started = self.progress.get("total") is not None or bool(self.progress.get("current_test_full_name"))
                last_change = time.monotonic()
                last_progress = progress
                print(f"Unity test job {self.job}: {progress[1]}/{progress[0]} complete"
                      f" ({progress[2] or 'waiting for next case'}).", file=sys.stderr, flush=True)
            time.sleep(max(0, min(1, cutoff - time.monotonic(), self.deadline - time.monotonic())))


def check_results(data, expected):
    results = object_value(data.get("result"))
    summary = object_value(results.get("summary"))
    cases = results.get("results")
    if (not isinstance(cases, list) or not cases
            or any(not isinstance(object_value(case).get("fullName"), str) for case in cases)):
        raise Blocked("TEST_JOB_NO_RESULTS", str(data.get("error") or "Coplay returned no detailed test results."))
    counts = Counter(case.get("fullName") for case in cases)
    missing = sorted(expected - counts.keys())
    unexpected = [case.get("fullName") for case in cases if case.get("fullName") not in expected]
    if missing or unexpected or any(counts[name] != 1 for name in expected):
        raise Blocked("TEST_SELECTION_MISMATCH", f"Missing or duplicate required cases: {missing or [name for name in expected if counts[name] > 1]}. Unexpected: {unexpected}.")
    if data["status"] == "failed" and type(summary.get("failed")) is int and summary["failed"] > 0:
        return {"status": "TEST_FAILURE", "reason": "Coplay reported failing test cases.", "summary": summary}
    if (data["status"] != "succeeded" or summary.get("resultState") != "Passed"
            or summary.get("total") != len(cases) or summary.get("passed") != len(cases)
            or summary.get("failed") != 0 or summary.get("skipped") != 0
            or any(case.get("state") != "Passed" for case in cases)):
        raise Blocked("TEST_RESULTS_INCOMPLETE", "Detailed Unity results do not establish a passing run.")
    return {"status": "PASS", "reason": "All selected cases passed in the reserved Editor.", "summary": summary}


def record_pending(path, pending):
    temp = path.with_suffix(".tmp")
    write_json(temp, pending)
    os.replace(temp, path)


def run_owned(editor, marker, expected):
    args = editor.args
    editor.connect()
    if args.wait_ready:
        if marker.exists():
            raise Blocked("PENDING_JOB", "Reconcile the earlier test dispatch with an ordinary probe before waiting.")
        editor.wait_ready()
    else:
        editor.check_idle(require_clean_scenes=not args.probe_only)
    if marker.exists():
        previous = object_value(json.loads(marker.read_text(encoding="utf-8")))
        if not args.confirm_idle:
            job = previous.get("job_id")
            if not job or previous.get("instance") != editor.instance or previous.get("port") != args.port:
                raise Blocked("PENDING_JOB", "Prior dispatch is unconfirmed. Verify the Editor has no active or queued test, then use --probe-only --confirm-idle --exclusive.")
            data = editor.poll(job)
            if data.get("status") not in {"succeeded", "failed", "cancelled"} or not data.get("result"):
                raise Blocked("PENDING_JOB", f"Prior job {job} has no confirmed completion. Inspect the Test Runner before reconciling.")
        marker.unlink()
    if args.probe_only:
        return {"status": "READY", "reason": "MCP and the target Editor responded. The Editor reports idle."}

    startup = args.startup_timeout
    pending = {"instance": editor.instance, "port": args.port, "evidence_directory": str(editor.run)}
    record_pending(marker, pending)
    started, wall_started_ms = time.monotonic(), int(time.time() * 1000)
    data = editor.command("run_tests", {
        "mode": args.test_platform, "testNames": sorted(expected), "initTimeout": int(startup * 1000),
    })
    editor.job = data.get("job_id")
    if not isinstance(editor.job, str) or not editor.job:
        raise Blocked("UNKNOWN_DISPATCH", "No job ID was returned. Unity may already have accepted the request.")
    record_pending(marker, {**pending, "job_id": editor.job})
    result = editor.wait(started, wall_started_ms, startup)
    write_json(editor.run / "test-job.json", result)
    if result.get("result"):
        # Only an actual terminal test result plus an idle Editor releases the interlock.
        try:
            editor.check_idle(require_clean_scenes=False)
        except Blocked as error:
            if error.code not in {"EDITOR_TEST_BUSY", "EDITOR_BUSY"}:
                raise
            time.sleep(max(0, min(1, editor.deadline - time.monotonic())))
            editor.check_idle(require_clean_scenes=False)
        marker.unlink()
    return check_results(result, expected)


def run_live(args, expected, parser):
    if not args.probe_only and not args.exclusive:
        parser.error("reserve the Editor and pass --exclusive before starting a live job")
    if args.confirm_idle and not (args.probe_only and args.exclusive):
        parser.error("--confirm-idle requires --probe-only and --exclusive")
    if args.wait_ready and not (args.probe_only and args.exclusive and not args.confirm_idle):
        parser.error("--wait-ready requires --probe-only and --exclusive without --confirm-idle")
    if args.startup_timeout is None:
        args.startup_timeout = 15 if args.test_platform == "EditMode" else 45
    limits = (args.rpc_timeout, args.startup_timeout, args.stall_timeout, args.timeout)
    if not 1 <= args.port <= 65535 or not all(0 < value < float("inf") for value in limits):
        parser.error("provide a valid port and positive finite deadlines")
    try:
        project = project_root(args.project)
    except (OSError, ValueError) as error:
        parser.error(str(error))
    run = new_run(args.out)
    print(f"Evidence: {run}", file=sys.stderr, flush=True)
    editor = LiveEditor(args, project, run)
    marker = None
    try:
        with project_lease(project, allow_stale_marker=True) as marker:
            result = run_owned(editor, marker, expected)
    except ProjectBusy as error:
        result = {"status": "BLOCKED", "code": "PROJECT_BUSY", "reason": str(error)}
    except Blocked as error:
        result = {"status": "BLOCKED", "code": error.code, "reason": str(error)}
    except (OSError, ValueError, KeyboardInterrupt) as error:
        result = {"status": "BLOCKED", "code": "LIVE_CLIENT_ERROR", "reason": str(error) or "Interrupted"}
    result.update(evidence_directory=str(run), project=str(project), instance=editor.instance,
                  job_id=editor.job, last_progress=editor.progress,
                  pending=bool(marker and marker.exists()))
    write_json(run / "nunit-gate.json", result)
    return result
