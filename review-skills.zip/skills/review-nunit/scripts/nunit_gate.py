#!/usr/bin/env python3
"""Run a test command and gate on fresh NUnit 3 results, or inspect an existing result."""

import argparse
from collections import Counter
from contextlib import nullcontext
from datetime import datetime, timedelta
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

# The coordinator owns shared subprocess and evidence handling.
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "review" / "scripts"))
from run_check import command_args, execute, new_run, write_json
from coplay_live import add_arguments as add_coplay_arguments, run_live
from unity_run import ProjectBusy, diagnose_startup, project_argument, project_lease, project_root, unity_command


def inspect(path, expected, whole_suite=False):
    report = {"xml": str(path.resolve()), "expected": sorted(expected)}
    try:
        root = ET.parse(path).getroot()
    except (OSError, ET.ParseError) as error:
        return dict(report, status="BLOCKED", reason=str(error))
    if root.tag != "test-run":
        return dict(report, status="BLOCKED", reason="Expected NUnit 3 <test-run> root.")

    cases = list(root.iter("test-case"))
    counts = Counter(case.get("result", "Unknown") for case in cases)
    names = Counter(case.get("fullname") for case in cases)
    missing = sorted(name for name in expected if names[name] == 0)
    ambiguous = sorted(name for name in expected if names[name] > 1)
    report.update(
        root_result=root.get("result"),
        start_time=root.get("start-time"),
        end_time=root.get("end-time"),
        discovered_count=root.get("testcasecount"),
        counts=dict(counts),
        missing_expected=missing,
        ambiguous_expected=ambiguous,
        non_passing=[
            {"name": case.get("fullname") or case.get("name"), "result": case.get("result"),
             "site": case.get("site"), "label": case.get("label")}
            for case in cases if case.get("result") != "Passed"
        ],
    )
    if root.get("result") == "Failed" or counts["Failed"]:
        return dict(report, status="TEST_FAILURE", reason="NUnit reported a failed run or case.")
    if not cases:
        return dict(report, status="BLOCKED", reason="No test cases were reported.")
    if whole_suite:
        try:
            discovered = int(root.attrib["testcasecount"])
        except (KeyError, ValueError):
            return dict(report, status="BLOCKED", reason="Whole-suite discovered count is missing or invalid; use a verified test manifest.")
        if discovered != len(cases):
            return dict(report, status="BLOCKED", reason="Whole-suite discovered and reported case counts differ.")
        test_filter = root.find("filter")
        if test_filter is not None and (len(test_filter) or (test_filter.text or "").strip()):
            return dict(report, status="BLOCKED", reason="Whole-suite result reports a test filter.")
    if missing or ambiguous:
        return dict(report, status="BLOCKED", reason="Required cases are missing or ambiguous.")
    if root.get("result") != "Passed" or counts["Passed"] != len(cases):
        return dict(report, status="BLOCKED", reason="One or more cases did not pass.")
    if any(suite.get("result") not in (None, "Passed") or suite.find("failure") is not None
           for suite in root.iter("test-suite")):
        return dict(report, status="BLOCKED", reason="Suite-level evidence is not passing.")
    try:
        coherent = (
            int(root.attrib["total"]) == len(cases)
            and int(root.attrib["passed"]) == len(cases)
            and all(int(root.attrib[key]) == 0 for key in ("failed", "skipped", "inconclusive"))
        )
    except (KeyError, ValueError):
        coherent = False
    if not coherent:
        return dict(report, status="BLOCKED", reason="NUnit summary and case results are incomplete or inconsistent.")
    return dict(report, status="PASS", reason="All reported and expected NUnit cases passed.")


def verify_run_window(result, process):
    """Check available NUnit timestamps against the local runner's lifetime."""
    try:
        def parse(value):
            if not isinstance(value, str) or not value:
                raise ValueError("Timestamp is missing")
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if parsed.utcoffset() is None:
                raise ValueError("Timestamp has no timezone")
            return parsed

        started = parse(process["started_utc"])
        finished = parse(process["finished_utc"])
        test_start = parse(result["start_time"])
        test_end = parse(result["end_time"]) if result.get("end_time") else test_start
        tolerance = timedelta(seconds=5)
        if test_start < started - tolerance or test_start > finished + tolerance:
            raise ValueError("Test start is outside the runner's execution window")
        if test_end < test_start or test_end > finished + tolerance:
            raise ValueError("Test end is inconsistent with the runner's execution window")
    except (KeyError, TypeError, ValueError) as error:
        result.update(status="BLOCKED", reason=f"Cannot establish result timing: {error}.")
    return result


def selection(parser, args):
    expected = set(args.expect)
    if args.expect_file:
        try:
            expected.update(name.strip() for name in args.expect_file.read_text(encoding="utf-8-sig").splitlines() if name.strip())
        except OSError as error:
            parser.error(str(error))
    if args.whole_suite == bool(expected):
        parser.error("choose either --whole-suite or at least one expected full test name")
    return expected


def add_selection(parser, *, allow_whole_suite=True):
    parser.add_argument("--expect", action="append", default=[], metavar="FULLNAME")
    parser.add_argument("--expect-file", type=Path, help="one exact NUnit fullname per line")
    if allow_whole_suite:
        parser.add_argument("--whole-suite", action="store_true", help="the command/job selects a documented whole suite")
    else:
        parser.set_defaults(whole_suite=False)


def add_run_limits(parser):
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--timeout", type=int, help="hard deadline in seconds (Unity: 600; other commands: 900)")
    parser.add_argument("--idle-timeout", type=int, help="log silence deadline in seconds (Unity: 120); 0 disables")
    parser.add_argument("--allow-stale-marker", action="store_true",
                        help="skip the Unity marker preflight only after confirming the project is closed")


def run_local(args, expected, parser):
    try:
        if args.mode == "unity":
            project = project_root(args.project)
            args.cwd = project
            args.command = unity_command(args, project, expected)
        else:
            if not args.cwd.is_dir():
                parser.error("--cwd must be an existing directory")
            command_project = project_argument(args.command, args.cwd)
            explicit_project = project_root(args.unity_project) if args.unity_project else None
            if command_project and explicit_project and not command_project.samefile(explicit_project):
                parser.error("--unity-project and -projectPath identify different projects")
            project = explicit_project or command_project
    except (OSError, ValueError) as error:
        parser.error(str(error))
    if args.timeout is None:
        args.timeout = 600 if project else 900
    if args.idle_timeout is None:
        args.idle_timeout = 120 if project else 0
    if args.idle_timeout < 0:
        parser.error("--idle-timeout cannot be negative")
    command_args(parser, args)
    if not any("{xml}" in arg for arg in args.command):
        parser.error("command must write NUnit 3 XML at {xml}")
    if args.whole_suite and any(arg.lower().split("=")[0] in {
        "-testfilter", "-testcategory", "-assemblynames", "-runsynchronously",
        "-orderedtestlistfile", "--filter", "--where",
    } for arg in args.command):
        parser.error("filtered execution requires expected test identities")
    run = new_run(args.out)
    print(f"Evidence: {run}", file=sys.stderr, flush=True)
    xml, log = run / "results.xml", run / "editor.log"
    command = [arg.replace("{xml}", str(xml)).replace("{log}", str(log)) for arg in args.command]
    try:
        lease = project_lease(project, args.allow_stale_marker) if project else nullcontext()
        with lease:
            process = execute(
                command, args.cwd, run, args.timeout, idle_timeout=args.idle_timeout,
                extra_logs=(log,), diagnose=diagnose_startup if project else None,
                heartbeat=15 if project else 0,
            )
    except ProjectBusy as error:
        result = {"status": "BLOCKED", "process": "PROJECT_BUSY", "reason": str(error)}
    except OSError as error:
        result = {"status": "BLOCKED", "process": "PREFLIGHT_ERROR", "reason": str(error)}
    else:
        result = inspect(xml, expected, args.whole_suite)
        result.update(process=process["status"], exit_code=process.get("exit_code"),
                      process_record=str(run / "process.json"))
        if process["status"] != "COMPLETED":
            detail = process.get("detail") or process.get("error") or process["status"]
            result.update(status="BLOCKED", reason=detail)
            if process.get("runner_reaped") is False:
                result["cleanup"] = "Runner exit could not be confirmed."
        else:
            if result["status"] in {"PASS", "TEST_FAILURE"}:
                verify_run_window(result, process)
            if process["exit_code"] != 0 and result["status"] == "PASS":
                result.update(status="BLOCKED", reason="XML passed but runner exited nonzero.")
            elif process["exit_code"] != 0 and result["status"] == "BLOCKED":
                result["reason"] = f"Runner exited with code {process['exit_code']}. {result['reason']}"
    result["evidence_directory"] = str(run)
    if project:
        result["project"] = str(project)
    write_json(run / "nunit-gate.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="mode", required=True)
    run_parser = subparsers.add_parser("run", help="execute a command and require newly written results")
    add_selection(run_parser)
    add_run_limits(run_parser)
    run_parser.add_argument("--cwd", type=Path, required=True)
    run_parser.add_argument("--unity-project", type=Path, help="enable Unity guards for a project-owned wrapper")
    run_parser.add_argument("command", nargs=argparse.REMAINDER)
    unity_parser = subparsers.add_parser("unity", help="run selected tests in an owned Unity batch editor")
    add_selection(unity_parser)
    add_run_limits(unity_parser)
    unity_parser.add_argument("--editor", type=Path, required=True, help="Unity executable matching ProjectVersion.txt")
    unity_parser.add_argument("--project", type=Path, required=True)
    unity_parser.add_argument("--test-platform", default="EditMode", help="EditMode, PlayMode, or a Unity BuildTarget")
    unity_parser.add_argument("--nographics", action="store_true", help="use only for suites that do not need graphics")
    coplay_parser = subparsers.add_parser("coplay", help="probe or run selected tests through a reserved Coplay Editor")
    add_selection(coplay_parser, allow_whole_suite=False)
    add_coplay_arguments(coplay_parser)
    inspect_parser = subparsers.add_parser("inspect", help="validate XML content only")
    add_selection(inspect_parser)
    inspect_parser.add_argument("--xml", type=Path, required=True)
    args = parser.parse_args()
    expected = set() if args.mode == "coplay" and args.probe_only else selection(parser, args)

    if args.mode == "inspect":
        result = inspect(args.xml, expected, args.whole_suite)
        result["provenance"] = "Caller must establish freshness and terminal job status."
    elif args.mode == "coplay":
        result = run_live(args, expected, coplay_parser)
    else:
        result = run_local(args, expected, unity_parser if args.mode == "unity" else run_parser)

    print(json.dumps(result, indent=2))
    return {"PASS": 0, "READY": 0, "TEST_FAILURE": 1, "BLOCKED": 2}[result["status"]]


if __name__ == "__main__":
    raise SystemExit(main())
