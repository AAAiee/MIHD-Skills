---
name: review-nunit
description: Run and audit NUnit tests for Unity or C# changes. Wait for the runner, validate fresh detailed results, and identify gaps in the tests supporting the changed behavior.
---

# Review NUnit

Read the [shared handoff](../review/references/handoff.md). Discover the project's actual NUnit runner and installed framework from project docs and package resolution. Use the configured project runner or CI command when it can provide NUnit 3 result XML. Use Unity's runner for tests that depend on Unity. An unrelated C# compile cannot establish Unity compilation or test results.

Select the project's required suites and regression cases relevant to changed behavior and affected dependencies. Use the [test verification procedure](references/test-verification.md) to audit the affected fixtures while the reserved Editor compiles, resolve material findings within the task's edit scope, and release the candidate for its test run. The [test design guide](references/test-design.md) is the companion for TDD and fixture authors.

Run each selected group with [the NUnit gate](references/runner.md). For a reserved single Editor connected to Coplay local HTTP, use [the live watchdog](references/coplay-live.md). Otherwise use the project-owned runner or a batch Editor on an idle project. Group exact NUnit case names by mode or target. Default to Edit Mode for editor behavior. Choose Play Mode or a built player when the evidence depends on runtime behavior or the target platform. Treat zero tests, missing expected cases, skipped/inconclusive required results, compilation or fixture failures, stale output, and timeouts as invalid or incomplete evidence. Separate behavior failures from infrastructure failures. Retry only after addressing a specific cause.

Record the candidate before and after execution, the runner, mode and exact selection, case counts, machine results and raw artifacts, and the claims supported or still open. Assign the stage PASS only when the required audit and execution evidence support the reviewed candidate.
