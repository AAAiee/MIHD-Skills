# Coplay watchdog for one open Unity Editor

Use this path with CoplayDev MCP for Unity 10.3.0 in local HTTP mode. The runner talks to the existing Coplay server on loopback through the same HTTP API as Coplay's CLI. It does not need a project copy or a new Unity instance. The CLI API is for local mode. For another transport or server, use the bounded [in-editor job procedure](runner.md#in-editor-or-remote-job). [Coplay 10.3.0 local routes](https://github.com/CoplayDev/unity-mcp/blob/v10.3.0/Server/src/main.py#L351-L498) · [Coplay CLI transport](https://github.com/CoplayDev/unity-mcp/blob/v10.3.0/website/docs/reference/cli.md#how-it-talks-to-unity)

Probe the intended Editor before changing anything. Use the port already configured in the Unity MCP window. The example uses Coplay's default local port.

~~~bash
python3 "/path/to/review-nunit/scripts/nunit_gate.py" coplay \
  --project "/path/to/project" --out "/path/to/review/evidence" --probe-only
~~~

READY means the local HTTP server responded, the bridge routed to the expected project, a loaded-scene query reached the Editor, and the Editor reported idle. It is not a test result. With multiple attached Editors, supply --instance with the exact Coplay hash. Coplay's Editor-state cache can retain an old timestamp while a healthy Editor's state is unchanged. Use the live read to check reachability. [Coplay Editor cache](https://github.com/CoplayDev/unity-mcp/blob/v10.3.0/MCPForUnity/Editor/Services/EditorStateCache.cs#L295-L365)

## Overlap audit with import and compile

When the reserved Editor is importing or compiling the candidate, run this read-only probe as a background command while fixture auditors work. Choose a deadline from the project's measured compile and reload time. The example allows four minutes for a transition that usually takes three.

~~~bash
python3 "/path/to/review-nunit/scripts/nunit_gate.py" coplay \
  --project "/path/to/project" --out "/path/to/review/evidence" \
  --probe-only --exclusive --wait-ready --timeout 240
~~~

The probe polls only after observing import, compile, or reload, checks each request against the short RPC deadline, and reports the wait as it progresses. After a confirmed transition it gives a lost Editor connection up to 12 seconds to recover. An initial bridge failure, unavailable server, wrong project, active test, or dirty scene returns to the coordinator for immediate diagnosis. If the bridge is initially inaccessible during a known reload, check the current Editor log or UI for that transition and re-probe when it advances. Neither this probe nor a retry requests another compile.

If an authorized script refresh is needed and Unity is idle, use the project's existing refresh path once. With Coplay 10.3.0, the installed `refresh_unity` MCP tool supports `scope="scripts"`, `compile="request"`, and `wait_for_ready=false` for a separate readiness check. A lost response is ambiguous. Confirm what Unity did in its state or logs before considering another request. READY confirms an idle, responding Editor with clean loaded scenes. Use a fresh Editor log window, project compile evidence, or the Editor UI to confirm the reviewed changes were imported and compiled successfully. Check this again for a repaired candidate. [Coplay refresh implementation](https://github.com/CoplayDev/unity-mcp/blob/v10.3.0/Server/src/services/tools/refresh_unity.py) · [Unity 2022.3 refresh lifecycle](https://docs.unity3d.com/2022.3/Documentation/Manual/AssetDatabaseRefreshing.html)

## Run the audited selection

Before running, coordinate exclusive use across agents and verify Unity has imported and compiled the reviewed candidate. The local project lock prevents overlapping launches from cooperating runners. Direct MCP calls from other agents must follow the same handoff. Select exact NUnit leaf names. Coplay's test service can save dirty scenes, so the watchdog checks the loaded scenes and blocks dispatch if any are dirty. Resolve those changes deliberately before retrying. [Coplay test start and scene saves](https://github.com/CoplayDev/unity-mcp/blob/v10.3.0/MCPForUnity/Editor/Services/TestRunnerService.cs#L230-L255) · [Loaded scenes and dirty flags](https://github.com/CoplayDev/unity-mcp/blob/v10.3.0/MCPForUnity/Editor/Tools/ManageScene.cs#L1559-L1578)

~~~bash
python3 "/path/to/review-nunit/scripts/nunit_gate.py" coplay \
  --project "/path/to/project" --out "/path/to/review/evidence" --exclusive \
  --expect "Tools.Editor.Tests.RenameTests.RenameSelection"
~~~

Use --expect-file for a list or --test-platform PlayMode for runtime tests in the open Editor. Use the batch runner for built-player runs. The live watchdog caps each request at 3 seconds. It polls the same job about once a second with no server-side long poll. It allows one read-only reconnect check for an interrupted poll. The defaults are 15 seconds to first test start in Edit Mode, 45 in Play Mode, 30 seconds without changes in test progress, and 5 minutes overall. Set --rpc-timeout, --startup-timeout, --stall-timeout, or --timeout only for known costs. Long-running cases and Play Mode transitions can need a larger budget. Logs record the last case, completed count, job ID, and HTTP evidence.

| Outcome | Immediate next action |
| --- | --- |
| Server unreachable | Check the local port and Coplay server status. Reconnect the existing local server if needed and rerun the read-only probe. |
| Server up, Editor disconnected or a live query times out | Check the MCP window and whether Unity is compiling, importing, changing modes, or blocked by a dialog. Resolve the observed state before probing again. |
| Editor busy or dirty scenes | Finish the current operation or handoff. Resolve unsaved changes deliberately. |
| Progress stops or the start response is lost | Keep the Editor reserved. Use the recorded job ID and the Unity Test Runner to determine whether the original job is running. A timed-out client request can leave work running in Unity. |
| Unfocused Editor with stalled progress | Bring the same Editor to the foreground, then inspect the existing job. Coplay has an upstream report of this behavior with 10.3.0 on macOS. |
| Confirmed test failure | Read the detailed case evidence and fix the observed cause before rerunning the relevant cases. |

The runner writes a pending record before dispatch. It sends only one start request. A later probe can reconcile a known job with a terminal test result and an idle Editor. If the dispatch was ambiguous or Coplay returned no result, inspect the actual Test Runner and confirm that no test is active or queued before using --probe-only --confirm-idle --exclusive. This only clears the watchdog's local pending record. If Coplay still reports a confirmed orphan, its documented clear_stuck command clears Coplay bookkeeping and requires an independent check that Unity is no longer running that job. It does not cancel a running test. Preserve the live Editor and the job evidence while resolving ownership. [Coplay job API](https://github.com/CoplayDev/unity-mcp/blob/v10.3.0/Server/src/services/tools/run_tests.py#L308-L475) · [ClearStuckJob implementation](https://github.com/CoplayDev/unity-mcp/blob/v10.3.0/MCPForUnity/Editor/Services/TestJobManager.cs#L116-L144) · [Unfocused Editor report](https://github.com/CoplayDev/unity-mcp/issues/1454)
