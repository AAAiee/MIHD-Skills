# Verify NUnit test quality

Use this procedure during review. For how to choose a test boundary, seam, fixture, or assertion, see the [test design guide](test-design.md).

## Scope and ownership

The stage lead owns the test plan, the candidate, and the runner. Use the diff, claims, and affected dependencies to identify the fixtures that can support or contradict those claims. Include affected shared fixture helpers, deleted cases, and changes to discovery or filtering. Audit that scope even when the project also requires a wider run. Give each material claim and each fixture group an owner, including any claim with no existing case.

Fixture auditors read source and existing evidence. They send findings to the stage lead and leave edits, Unity, MCP, and test execution to the lead. The lead can implement justified test changes when implementation or repair is already in scope. A review-only invocation reports the finding and proposed change. The same lead, or one designated repair agent with a bounded set of files, applies one batch of repairs before the final run.

## Schedule the audit and compile together

1. **Start two tracks on the same candidate.** As soon as the first fixture group is identified, dispatch its audit. In parallel, reserve the Editor and check its state. Reuse an in-progress import or compile for this candidate. If source changes still need import, use the project's supported refresh once, when authorized and safe. Observe the existing transition if it starts automatically. If the candidate is already loaded, prepare the runner and selection while the audit proceeds. For Coplay, use the [bounded readiness probe](coplay-live.md#overlap-audit-with-import-and-compile). For batch and standalone runners, use documented, independent build or discovery steps where they exist. If the runner couples compilation and execution, start it after the audit and let that invocation do both.
2. **Parallelize by affected fixture group.** As a starting point use one auditor for 1–3 affected fixtures, two for 4–8, and three for 9 or more, up to the available worker slots. A single complex fixture or shared helper can cost more than several small fixtures. Keep tightly related fixtures and their claim together. Split large work by independent behavior, and assign one owner to shared infrastructure. Fill spare slots only with distinct work. If slots are scarce, the lead audits a group while the readiness probe runs. No fixture count is needed to audit a material gap with no test.
3. **Collect actionable findings as they arrive.** Give each auditor the pinned candidate and baseline, requirements, assigned paths and claims, this procedure, and a checkpoint within the expected compile window. Require the reviewer to report a blocker immediately and return completed and outstanding claims at the checkpoint. At the join, take over or reassign only unfinished scope when a worker stalls. An outstanding required claim stays open.
4. **Join audit and readiness.** Run the selected cases after audit findings are resolved for the candidate under test. For a live Editor, require evidence that the candidate's import and compile completed successfully or that the exact candidate was already loaded. The Editor can report idle before a queued compile starts. For a review-only finding that remains open, a run of valid selected cases can still provide diagnostic evidence. If the audit finishes first, monitor the existing compile within its deadline. If compilation finishes first, finish the remaining audit and use the ready Editor. A failed compile or bridge check changes the execution track to diagnosis while source review can continue. Keep the Editor reserved until any uncertain test job is reconciled.
5. **Recheck repairs as a batch.** Collect the necessary source fixes, then apply them together. If this changes what Unity loads, pin the updated candidate and verify its own import and compile. Finish or stop the previous read-only probe before starting a new probe or test gate. Check for a queued automatic import before requesting another refresh. Reaudit the repaired claims, fixtures, shared helpers, or filters affected by the fixes during that transition. Keep earlier findings tied to their original revision and carry forward audit evidence only for unaffected claims whose inputs are unchanged. Regenerate the exact selection and run it in one group per mode or target. A later test failure calls for a focused diagnosis and rerun of the affected selection after a specific repair.

## Audit each assigned claim

Report the requirement and source, case and location, concrete assertion, plausible wrong behavior, and outcome. Trace the fixture through the production entry and any substitutes to the observable result. Check whether the setup could do the work itself, the expected value could come from the implementation, or a fake could bypass the component the claim concerns. Check test isolation, ordering dependencies, cleanup, and whether Unity Edit Mode, Play Mode, or a built player is required. Mark where a live workflow check is needed.

Compare test changes with the baseline and the contract. Examine changed expected values, weakened assertions, catch-all exceptions, skipped cases, removed inputs, and filters that no longer reach a required test. Check historical red evidence when available. The relevant case must fail on the intended behavioral assertion. An infrastructure or fixture failure provides separate evidence.

For a consequential claim whose assertion sensitivity remains uncertain, use an existing failing-before result or an existing fault-injection seam first. If authorized and practical, try one realistic deliberate regression in a disposable context and verify the specific assertion fails. Keep the final candidate and its test run separate. Record a material gap if the defect survives or convincing evidence remains unavailable. Apply this check selectively and preserve the normal single-run path for clear assertions. [Google on mutation testing](https://testing.googleblog.com/2021/04/mutation-testing.html)

## Decide what to repair and what the run proves

| Finding | Repair when edits are in scope |
| --- | --- |
| Real production behavior violates the contract | Retain the expectation. Fix the behavior when production edits are in scope. |
| A valid case has a weak assertion or faulty setup | Repair the fixture or assertion against an independent expected result. |
| A consequential behavior has no convincing case | Add a focused case or move the claim to the appropriate live check with evidence. |
| A case is obsolete or redundant | Remove or consolidate it after showing which required behaviors and input classes still have equivalent coverage. Cite the surviving case or the approved contract change. |
| The expected behavior is unresolved | Record the deciding question and keep the claim open. |

Review every change to a required expectation or case selection against the contract or a demonstrated harness defect. A green result by itself supplies no justification for deleting or weakening a case. Record the reason and the evidence for each repair or removal.

Keep three things distinct in the report. List which cases executed, which behaviors the assertions support, and which material risks remain open. Report unresolved evidence gaps even after a passing run. Bind the audit and the run to the same candidate, including relevant working-tree files.
