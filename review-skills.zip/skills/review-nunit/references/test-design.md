# Designing NUnit tests for Unity tools

Use this guide with your existing TDD workflow, before choosing or writing a test. It helps you select behavior to cover, choose where to exercise it, and design a fixture and assertion that expose the failure. Follow the project's test conventions and installed NUnit and Unity Test Framework versions.

## Decide what deserves a test

Start from the requested behavior, existing callers, and assets the change can affect. Read the requirements, defect reproduction, and nearby tests. Phrase each material promise as “given this starting state, when the caller does this, these observable results follow.” Include something that must remain unchanged when the risk is an unintended edit.

For each promise, name a plausible regression. Examples include a threshold off by one, updating unselected objects, losing a prefab override on reopen, or delivering the same completion event twice. A case earns its place when it distinguishes the intended outcome from a plausible wrong one. Prefer this order:

1. Cover the changed result and reuse existing coverage for affected contracts.
2. Add the smallest representative case for each distinct, consequential failure. Check boundaries where behavior changes, such as the first disallowed value. Sample one input per meaningful equivalence class, a group of inputs that should behave the same way.
3. Add cancel, retry, partial failure, second invocation, or legacy data only when the feature promises something about that situation or the change puts it at risk. Work out the required outcome first. An operation may allow partial success or intentionally create another output on retry.
4. Stop when the planned cases distinguish the relevant failures. Expand coverage for shared paths with wider impact or project requirements. Use line and branch coverage to find gaps worth investigating. Honor project thresholds without adding cases solely to raise a number. An executed line does not establish that an assertion would catch a defect there. [Google on code coverage](https://testing.googleblog.com/2020/08/code-coverage-best-practices.html)

A straightforward refactor with suitable existing coverage may need only those tests. A defect with a known reproduction deserves a case at the narrowest production entry that reproduces it. If a material behavior is ambiguous, get the rule from the project owner before encoding it. If a required claim cannot be exercised reliably, record the gap and the evidence needed to close it. [Google's behavior-focused test guidance](https://testing.googleblog.com/2014/04/testing-on-toilet-test-behaviors-not.html) · [.NET unit testing practices](https://learn.microsoft.com/en-us/dotnet/core/testing/unit-testing-best-practices)

Before writing tests, record a small plan in the existing feature brief or review evidence. For each material claim, name **the failure, production entry, environment, fixture, expected result, and existing or proposed case**. Note any claim that needs a different check. For a tiny change, a sentence or two is enough.

## Choose the smallest test that can expose the failure

Use [the shared coverage map](../../review/references/coverage.md) to allocate claims across tests and live checks. Apply these rules when NUnit is the right tool:

- **Synchronous rules and decisions.** Call the production operation or policy with small explicit inputs. Prefer a plain NUnit test with no scene, file, or Unity lifecycle setup when the result is independent of them. A rule used only inside a command can be exercised through the command if that keeps the test cheap and readable.
- **Unity Editor behavior.** Use Edit Mode with real Unity objects or assets when the claim depends on serialization, Undo, prefab overrides, AssetDatabase, scene ownership, or import. Call the same operation the tool calls. Create only the objects needed to distinguish correct from incorrect behavior. A fake store can exercise decisions around an edit. Proving Unity stored the edit requires Unity.
- **Runtime behavior.** Use Play Mode when the result depends on activation, frames, physics, coroutines, or a runtime consumer. Exercise the actual lifecycle. Prepare data before the object activates when initialization consumes it. A target player is warranted when the claim depends on a player build or platform. Editor-only tool logic can stay in Edit Mode even when the tool produces an asset that has a separate runtime consumption claim. [Unity Test Framework modes](https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/manual/edit-mode-vs-play-mode-tests.html) · [Unity 2022.3 lifecycle](https://docs.unity3d.com/2022.3/Documentation/Manual/ExecutionOrder.html)
- **Input routing and visual quality.** Use a supported interaction or rendering check when the claim is about click, drag, focus, layout, or visual feedback. A direct C# call verifies the operation it enters. The live check verifies the user can invoke it through the intended controls. One end-to-end case can check wiring while focused NUnit cases cover rule variants.

## Choose the boundary and seams

A **test boundary** is where the test supplies input and observes a result. A command's `Apply` method can be a test boundary even when the test substitutes nothing. A **seam** lets the caller select a dependency or behavior without editing the code that uses it. A command that accepts a clock has a seam at that argument. **Dependency injection** supplies the dependency at that seam. In production the composition point supplies the real clock. A test can supply a fixed clock. These are different decisions. First choose what to exercise. Then decide what, if anything, to substitute. [Feathers on seams](https://www.informit.com/articles/article.aspx?p=359417&seqNum=2)

Trace the real route from a caller to the behavior and its effects. A tool may have a window or command that reads Unity state, an operation that makes decisions, an adapter that applies changes through Unity, and a caller that consumes the result. These are possible roles in the existing code. Add a role only when it owns a useful responsibility. Test through the smallest stable entry that includes the cause of the failure. A boundary can be internal to the project when it has real callers and a meaningful contract. Follow the project's assembly and visibility conventions. Avoid opening up private helpers solely to test them.

| Plausible failure | Where to exercise it | What stays real |
| --- | --- | --- |
| A naming, filtering, placement, or validation rule returns the wrong result | Call the production policy with explicit values. If the command is already cheap, exercise the rule there. | The rule and any cheap collaborators. |
| A valid plan becomes the wrong edit or a rejection still writes | Call the production command that applies the policy and coordinates effects. | The command and its actual policy. Use an owned destination or a controlled substitute only for the relevant effect. |
| Unity fails to persist a change, record an override, restore Undo, or import an asset | Call the tool's command or real Unity adapter in Edit Mode and observe the actual effect. | Unity objects, assets, and the Unity API that supplies the behavior. |
| An object starts in the wrong state or a real runtime event is lost | Exercise the runtime component or consumer through activation, a frame, or another actual lifecycle transition. | The component, player loop, and any Unity wiring needed by the claim. |
| A control never invokes the command, sends the wrong inputs, or hides the result | Exercise the supported input and observe the resulting editor state and feedback. | The actual user entry, its wiring, and the relevant output. |

An adapter can have its own test boundary when mapping to Unity is itself the risk. Prefer an operation-level test when a direct adapter call would miss how production invokes it. Keep a representative test of the production wiring when it could fail independently of the policy. Reuse the focused cases for variations in the same rule. [Google on test scope and maintainability](https://abseil.io/resources/swe-book/html/ch12.html)

## Decide what to inject and why

Prefer a real implementation when it is cheap, reliable, and safe. Pass known **data** as arguments when it is already available at the boundary. Inject a **dependency** when the operation must obtain or affect something it cannot reasonably control. Use an existing constructor, parameter, or composition point. Prefer a narrow dependency expressed in domain terms when the operation needs several related capabilities. A function argument is enough for one capability. Skip a new abstraction if the same behavior can be tested cleanly with the existing entry and fixture. [Google on test doubles and fidelity](https://abseil.io/resources/swe-book/html/ch13.html)

| Dependency or input | Good reason to vary it | What the test proves |
| --- | --- | --- |
| Selection, settings, paths, or transform inputs | The caller already knows the values. Pass them directly as inputs or a snapshot so the rule can be exercised independently of editor globals. | Behavior for those inputs. Use a real selection or window check if collecting the values from Unity is part of the claim. |
| Clock | The operation reads time to decide expiration, cooldown, or retry. Supply a fixed time or advance a controlled clock across the threshold. | The production rule changes state at the agreed time. A real frame or timer test covers scheduling when that is a separate promise. |
| Random source or ID generator | A rare outcome must be reproducible, or the same seed must recreate a result. Use explicit inputs or a controlled source. | The outcome or invariant for those choices. Assert the exact random sequence only if compatibility promises it. |
| Network, storage, or external process | The real dependency is costly, unsafe, or unreliable for the intended failure. Force a timeout, rejection, or failure after the first successful effect. | The production operation handles the supplied outcome. Real adapter tests are needed for actual protocol, disk, or Unity semantics when those matter. |
| Async completion or external events | The order of completion or cancellation controls the result. Use a completion signal the test can release and observe, or drive the real lifecycle when testing Unity scheduling. | The outcome for a specific event order. A fake scheduler does not prove Unity invokes an operation on the correct frame. |
| A notification or outbound request | Sending the message, sending it once, or sending nothing after a rejection is part of the public contract. Record the boundary output. | The externally meaningful message or absence of one. Internal helper call counts are usually incidental. |

A **stub** supplies a controlled answer, such as a failure on the second write. A **fake** implements useful behavior, such as a small in-memory store. A **recording double** captures observable effects, such as a sent message. Use the simplest one that exercises the claim. Keep a fake's behavior close to the real dependency where it matters. If the test asserts an interaction, explain which external caller or system depends on it. Avoid production branches that behave differently just because a test is running.

**Example of injection for time.** This illustrative operation samples the current time when called. Its contract makes a retry eligible at the deadline. An operation that already receives the current time as data can test the same rule with an ordinary argument.

~~~csharp
using System;
using NUnit.Framework;

public sealed class RetryGate
{
    private readonly Func<DateTimeOffset> utcNow;

    public RetryGate(Func<DateTimeOffset> utcNow)
    {
        this.utcNow = utcNow;
    }

    public bool CanRetry(DateTimeOffset retryAt) => utcNow() >= retryAt;
}

public sealed class RetryGateTests
{
    [TestCase(-1, false)]
    [TestCase(0, true)]
    [TestCase(1, true)]
    public void CanRetry_BecomesEligibleAtDeadline(int offsetSeconds, bool expected)
    {
        var deadline = new DateTimeOffset(2026, 1, 1, 12, 0, 0, TimeSpan.Zero);
        var gate = new RetryGate(() => deadline.AddSeconds(offsetSeconds));

        Assert.That(gate.CanRetry(deadline), Is.EqualTo(expected));
    }
}
~~~

Production supplies a real clock at composition, such as `() => DateTimeOffset.UtcNow`. The test supplies the exact before, at, and after times. NUnit checks the eligibility rule. If the feature also promises to retry automatically, exercise the actual trigger or scheduling path separately.

## Write the test so failure is informative

1. **Name the scenario and promise.** Use the repo's naming convention. A name like `ApplyRename_MixedSelection_LeavesUnselectedObjectsUnchanged` tells a maintainer what broke.
2. **Arrange a minimal, distinguishing fixture.** Use input values that make wrong implementations visibly wrong. A selection test with every object selected cannot expose editing too many objects. Keep scenario-specific setup visible. Hide routine construction and cleanup in fixture helpers that have clear ownership.
3. **Act through production.** Invoke the real operation at the chosen boundary. Avoid reflection into private helpers, copying the implementation, or recreating the production effects in test setup. One scenario can involve several steps when the contract is a round trip, such as Apply → Undo → Redo. Check the result at the relevant steps.
4. **Assert against an independent expected result.** Use known literals, a worked example, an approved fixture, or an invariant from the contract. Check the actual result, affected state, and any required non-effects. Assert order only when order is promised. Use a tolerance grounded in the contract for floating-point values. Assert an error type or code when that is the public result. Check exact wording only when wording is part of the requirement.
5. **Check that it discriminates.** What realistic wrong change makes this test fail? Would a refactor that preserves the behavior leave it passing? Tighten or remove a test that cannot answer both.

Prefer `[Test]` for synchronous behavior. Use `[TestCase]` for a small set of different inputs that exercise the same action and assertions. Use separate named tests when the scenario, setup, or consequence changes. Use `[UnityTest]` when the test must yield to the Editor or player loop. Check parameterization and async support against the installed framework. For example, Unity Test Framework 1.1 documents `[ValueSource]` for parameterized `[UnityTest]` methods. Wait for an observable condition with a bounded deadline when completion is asynchronous. Assert the effect after the wait. Keep an expected `LogAssert.Expect` local to the case and register it before the action. Unexpected errors should remain visible. [NUnit TestCase](https://docs.nunit.org/articles/nunit/writing-tests/attributes/testcase.html) · [UnityTest parameterization](https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/manual/reference-tests-parameterized.html) · [Unity LogAssert](https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/api/UnityEngine.TestTools.LogAssert.html)

Illustrative C# test. The example contract numbers entries from 1 and pads to at least two digits. Replace the operation with the project's actual entry. Each expected name is worked out independently.

~~~csharp
[TestCase(1, "Prop_01")]
[TestCase(10, "Prop_10")]
[TestCase(100, "Prop_100")]
public void FormatName_PadsToAtLeastTwoDigits(int index, string expected)
{
    var actual = RenameNames.Format("Prop", index);

    Assert.That(actual, Is.EqualTo(expected));
}
~~~

## Show that the test can catch the bug

A rename test that asserts only `result.Success` can pass after the command renames every object. Give it two selected objects and an unselected object with a distinguishable name. Assert the two exact new names and the original name of the unselected object. The defect now has a specific assertion that detects it.

## Make Unity integration tests prove the real effect

Use the project's existing test assembly for the environment and dependencies. Group cases around a command, policy, or feature contract so an agent can find and run the related cases together. Put tests that reference `UnityEditor` in the Editor test assembly. A runtime fixture that must run in a target player needs a compatible test assembly and fixture data available to the build. Keep expensive scene and asset setup out of cases that can prove their claims with plain inputs. [Unity Test Framework modes and test assembly configuration](https://docs.unity3d.com/Packages/com.unity.test-framework@1.1/manual/edit-mode-vs-play-mode-tests.html)

- **Isolation.** Use fixtures that own their assets, scenes, GameObjects, and subscriptions. Use unique temporary paths when asset files are required. Restore any selection, active scene, settings, or event subscriptions you changed, and clean up on failure. Control time, random seeds, and input order when they affect the result. The test should pass alone and in a different order. Use a reserved, clean Editor context for tests that need shared Editor state. If failure could change the user's scene or undo their work, use a test context that can absorb that failure before running it.
- **Undo and Redo.** Start from distinguishable values. Invoke the edit and check the changed values. Use one ordinary Undo when the contract promises one Undo, then check restoration. Check Redo when promised. Protect pre-existing undo history even if the edit forgets to register an undo operation. Use the normal timing for the effect. For example, Unity documents deferred change recording for `Undo.RecordObject`. A test that adds the missing Undo bookkeeping cannot catch that defect. [Unity 2022.3 Undo.RecordObject](https://docs.unity3d.com/2022.3/Documentation/ScriptReference/Undo.RecordObject.html)
- **Persistence and prefab ownership.** Start with a clean owned fixture. Verify dirty state or override registration when it is part of the promise. Use the expected save path. If the feature promises auto-save, exercise the feature without saving for it. If the user is meant to save afterward, save only the owned fixture through the relevant path. Close or unload and read the data back through a fresh object, then check values and retained references. For instance edits, check that the source and other instances stay unchanged when that is the contract. A forced `SaveScene` can write a clean scene and hide missing dirty-state bookkeeping. [Unity 2022.3 SaveScene](https://docs.unity3d.com/2022.3/Documentation/ScriptReference/SceneManagement.EditorSceneManager.SaveScene.html) · [Unity 2022.3 prefab overrides](https://docs.unity3d.com/2022.3/Documentation/ScriptReference/PrefabUtility.RecordPrefabInstancePropertyModifications.html)
- **Runtime consumption and timing.** Set up an owned asset and its real consumer. Trigger the relevant load, activation, or frame. Check the outcome the user depends on, such as the expected reference resolving and driving a state change. If repeat activation or disabled domain reload is supported and affected, exercise that configuration explicitly. One call directly into the implementation cannot establish that the runtime invokes it at the right time. [Unity lifecycle](https://docs.unity3d.com/2022.3/Documentation/Manual/ExecutionOrder.html) · [Unity 2022.3 domain reload](https://docs.unity3d.com/2022.3/Documentation/Manual/DomainReloading.html)

Example coverage plan for a generic rename command. Assume the contract says to rename selected objects, leave unrelated objects alone, and support one Undo. Check naming variants at the rule boundary. In a reserved Edit Mode fixture, arrange two selected objects with different old names and one unselected sentinel. Call the same Apply operation the tool uses and assert both exact new names plus the unchanged sentinel. Then perform the promised Undo and assert both exact original names. Add a reopen test only if the change affects the persistence promise. Use a live workflow check for the Apply button's binding. Each case earns its place by protecting a different behavior.

For an export that promises all-or-nothing writes, induce a failure on the second output. Assert the reported error and inspect the owned destination for restored old contents and absence of partial output. A stub can make the failure deterministic. Use the real storage adapter if the claim concerns the actual files. For a generated asset that a runtime component consumes on activation, load the fixture through the real consumer in Play Mode and assert the resulting state. Add a target-player case when that behavior differs by target or depends on the build.

