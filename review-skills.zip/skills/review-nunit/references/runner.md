# Running the NUnit gate

Use Python 3.9 or newer and keep the sibling skill folders together. Run [nunit_gate.py](../scripts/nunit_gate.py) from the actual skill path. It starts the supplied command without a shell, waits with a deadline, and uses a new result path each time. It records the raw XML, editor log if supplied, stdout/stderr, process record, and gate result. Exit 0 requires a completed runner with code 0, coherent passing NUnit 3 XML, and a test start timestamp within the local process window, allowing five seconds for timestamp precision. Exit 1 means NUnit reported a failure, which the reviewer must classify. Exit 2 means the result cannot support a pass. If timestamps are missing, ambiguous, or affected by host clock skew, obtain independent job evidence and report the gate as blocked until provenance is established.

## Targeted Unity runs

Choose the smallest group that covers the changed behavior and its affected dependencies. Use existing test ownership, fixtures, and requirements to select the cases. Run the group in one editor launch per mode or target. Give the script exact NUnit leaf fullnames from test discovery, including arguments for parameterized cases. It builds the Unity filter from the same names that it checks in the results.

~~~bash
python3 "/path/to/review-nunit/scripts/nunit_gate.py" unity \
  --editor "/path/to/Unity" --project "/path/to/test-copy" \
  --out "/path/to/feature/review/nunit" \
  --expect "Tools.Editor.Tests.RenameTests.RenameSelection"
~~~

Use repeated --expect options or --expect-file with one fullname per line. EditMode is the default. Use --test-platform PlayMode for runtime behavior in the editor, or a documented Unity BuildTarget such as StandaloneWindows64 for a player run. Choose a matching installed editor and verify the flags for the project's Test Framework version. Use --whole-suite only for a required unfiltered run. Keep the test copy current with the candidate and reuse its Library cache across runs. Use --nographics only when the cases and platform do not need graphics.

## Project-owned commands

Use a project-owned runner when it supplies the needed configuration, discovery, or environment. Confirm its flags for the installed package. This example runs a documented whole EditMode suite:

~~~bash
python3 "/path/to/review-nunit/scripts/nunit_gate.py" run \
  --cwd "/path/to/project" --out "/path/to/feature/review/nunit" \
  --timeout 900 --whole-suite -- \
  "/path/to/Unity" -batchmode -projectPath "/path/to/project" \
  -runTests -testPlatform EditMode -testResults '{xml}' -logFile '{log}'
~~~

Substitute the actual Unity executable, absolute project and evidence paths. For a selected run, replace --whole-suite with repeated --expect arguments or --expect-file containing one exact NUnit fullname per line. Add the matching runner filters after --. The same expected-name mechanism also supports an independently discovered manifest for a whole suite. Use separate calls for required EditMode, PlayMode, or target runs. For a non-Unity C# runner, pass its argument array and configure its NUnit 3 logger to write at {xml}. The script replaces {xml} and {log} in the command arguments.

Use --whole-suite only for a documented, unfiltered selection. It checks the reported discovered count against the reported cases and rejects an XML filter. The script recognizes several common command-line filter flags. These checks cannot detect filters hidden in every wrapper or discovery configuration. The reviewer must establish the intended selection, including the project, assemblies, platform, and wrapper behavior. Prefer an independently obtained case manifest when possible. A matching count alone does not prove full suite discovery. The recorded execution window helps detect old results; it cannot prove which code a runner loaded. Bind the job and the code state independently.

If a local wrapper hides -projectPath, supply --unity-project so it receives the same project guard and defaults as the direct Unity command.

## Ownership and deadlines

Unity batch runs take a non-waiting local lock for the canonical project directory. Cooperating runners on the same host must share the same system temporary directory. A competing run immediately reports PROJECT_BUSY. The runner also treats Temp/UnityLockfile as a conservative preflight signal and recognizes Unity's project-busy and batch-abort messages. The marker can survive a crash. After independently confirming the editor and runner are closed, --allow-stale-marker skips that preflight check. Unity's own project lock still applies.

Use an idle project copy with its own writable Library, assets, and test outputs while another agent drives the interactive editor. Give each concurrent batch worker its own copy. Partition only independent tests and combine the per-copy results against the original plan. Measure startup, import, and run time before sharding. A single warm batch can be quicker than multiple cold editors. The Unity runner has no documented NUnit worker setting in its CLI. Use standalone NUnit parallelism only in a separate .NET suite whose tests can safely share a process.

Unity runs default to a 600-second hard deadline and a 120-second log-silence deadline. The runner writes a status update to stderr every 15 seconds and saves the logs and reason when it stops. A quiet import or player build can legitimately take longer. Set --timeout and --idle-timeout from measured runs for that target. Use --idle-timeout 0 when the runner does not emit dependable logs. The hard deadline still applies. The runner attempts bounded cleanup of its own process tree. Treat unconfirmed cleanup as blocked. Investigate the recorded cause before retrying.

## In-editor or remote job

For a single open Editor using Coplay 10.3.0 in local HTTP mode, follow [the live Coplay runner](coplay-live.md). It supplies bounded requests, a test progress watchdog, and an interlock for uncertain dispatches.

Use the live editor only when the coordinator can reserve it for the entire run. All agents that can drive it, including MCP callers, must respect that reservation. The local batch lock does not arbitrate direct MCP calls. If ownership cannot be established, use an isolated batch copy or report the live check as blocked.

For a project-specific job API, use its installed schema. Save the returned job ID and use bounded calls and an overall deadline while polling to a terminal state. On timeout, cancel that job if the API supports it and verify it has stopped before releasing the editor. If termination cannot be confirmed, keep the editor marked busy and report the job ID and last known state. Save the fresh XML in this run directory if available, then run:

~~~bash
python3 "/path/to/review-nunit/scripts/nunit_gate.py" inspect \
  --xml "/path/to/feature/review/nunit/results.xml" --whole-suite
~~~

Use the appropriate expected cases for selected runs. Inspect validates XML content only. Bind it to the terminal job and candidate separately. If the driver supplies detailed structured results without XML, apply the same criteria to those results and preserve the terminal response. A job ID, a “started” response, or an aggregate count without required case evidence is insufficient. Verify logs for compilation errors and any project-required failure conditions.

References: [Unity Test Framework command-line arguments](https://docs.unity3d.com/Packages/com.unity.test-framework@1.4/manual/reference-command-line.html), [Unity batch mode and project ownership](https://docs.unity.com/en-us/engine/6000.0/manual/unity-editor/command-line-arguments/editor#batch-mode-arguments), [NUnit framework parallel execution](https://docs.nunit.org/articles/nunit/technical-notes/usage/Framework-Parallel-Test-Execution.html).
