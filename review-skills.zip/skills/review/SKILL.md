---
name: review
description: Coordinate an ordered review of Unity and C# productivity tools. Invoke specialist skills for NUnit, project code standards, real workflows, architecture, and rendered UI design. Use for a pre-handoff review of an implementation, refactor, or tool change.
---

# Review

Review the requested scope and return a verdict backed by evidence. Use the five linked skills as the procedures for their respective stages. This is a review. Modify product code or tests only when the caller also requests fixes.

## Prepare one review brief

1. Read project guidance and the feature contract, design references, changed code, and documented run commands. Pin the baseline and candidate, including working-tree changes in scope. Use the project's version control and record how to reproduce the comparison. For a proposal, identify the design revision and the validation that can be done before implementation.
2. State each material claim as a fixture, action, expected result, and independent way to observe it. Include compatibility, data protection, recovery, or performance where the change puts those at risk. [Coverage examples](references/coverage.md) explain the split between a C# operation and the actual user path.
3. Locate the configured feature root and keep evidence in one run directory there. Record Unity/package versions when applicable, runner commands and filters, project/editor identity, disposable fixture, and applicable standards. Read the [handoff and verdict contract](references/handoff.md) before dispatching.
4. Mark applicability before execution. Explain each excluded stage. If a missing requirement changes the verdict, ask the smallest relevant question and continue checks that do not depend on it. Treat assumptions as such.

## Execute the stages in order

| Stage | Skill | Apply when |
| --- | --- | --- |
| 1 | [review-nunit](../review-nunit/SKILL.md) | Affected behavior has NUnit coverage, needs a regression test, or the project requires the suite. An implementation with required but missing tests has an evidence gap. |
| 2 | [review-standards](../review-standards/SKILL.md) | Code or project configuration changed. |
| 3 | [review-workflow](../review-workflow/SKILL.md) | An affected requirement involves Unity integration, a user entry point, generated output, external effects, or recovery. |
| 4 | [review-architecture](../review-architecture/SKILL.md) | Production code or framework design changed. Scale from one relevant dependency/ownership check to a before/after review of a redesign. |
| 5 | [review-design](../review-design/SKILL.md) | Visible layout, interaction design, feedback, or rendered output changed, or design review was requested. |

Wait for each stage to finish and retain its evidence before starting the next. The NUnit gate runs the required suites and waits for actual completion. A failed or blocked required stage halts normal progression. Mark later required stages NOT RUN. If the user requests a diagnostic sweep, continue applicable checks in sequence and keep the failed or blocked result visible.

Reserve a single live Unity Editor across the stage that uses it. If a test runner reports a pending or uncertain job, keep the Editor reserved until the job is reconciled. During a diagnostic sweep, continue only checks that can proceed without that Editor.

When delegation is available, assign each stage to a separate fresh agent. For NUnit, reserve the available slots for fixture auditors and use the [NUnit scheduling procedure](../review-nunit/references/test-verification.md#schedule-the-audit-and-compile-together). The coordinator can lead the NUnit stage directly and dispatch fresh auditors when a separate stage lead would consume a slot or the host limits nested delegation. Pass the exact skill path and review brief and instruct each reviewer to follow it. Give reviewers the inputs and raw evidence they need, including workflow captures for design. Keep previous reviewers' opinions out of the next agent's brief unless needed to resolve a specific finding. Wait for the report before handing the Editor or test workspace to another agent. If the host has no delegation, have the stage lead perform the audit while any independent runner preparation proceeds. Loading a skill gives the reviewer instructions. The coordinator still dispatches the agent and checks its output.

## Report

Run the verdict script on the stage ledger as described in the handoff contract. Review the raw evidence behind material findings. Keep the verdict for each stage visible. Call out what is safe to rely on, what failed, and the smallest next action for each blocker. Cite requirements, locations, and actual artifacts. If authorized fixes change the candidate, rerun the affected gates on the new state and retain the earlier evidence.

