#!/usr/bin/env python3
"""Run one project check with a deadline and preserve its process evidence."""

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def new_run(out):
    out.mkdir(parents=True, exist_ok=True)
    return Path(tempfile.mkdtemp(prefix="run-", dir=str(out.resolve())))


def stop(process):
    if process.poll() is not None:
        return True
    try:
        if os.name == "posix":
            os.killpg(process.pid, signal.SIGKILL)
        else:
            try:
                subprocess.run(
                    ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                    stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL, timeout=3, check=False,
                )
            except (OSError, subprocess.TimeoutExpired):
                pass
            if process.poll() is None:
                process.kill()
    except ProcessLookupError:
        pass
    except OSError:
        return False
    try:
        process.wait(timeout=3)
    except subprocess.TimeoutExpired:
        return False
    return True


def log_state(path):
    try:
        info = path.stat()
        return info.st_size, info.st_mtime_ns
    except FileNotFoundError:
        return None


def watch(process, started, timeout, idle_timeout, logs, diagnose, heartbeat):
    last_activity = started
    next_update = started + heartbeat if heartbeat else None
    states = dict.fromkeys(logs)
    while True:
        now = time.monotonic()
        code = process.poll()
        changed = []
        for path in logs:
            state = log_state(path)
            if state != states[path]:
                changed.append(path)
                states[path] = state
        if changed:
            last_activity = now
            diagnostic = diagnose(changed) if diagnose else None
            if diagnostic:
                return diagnostic
        if code is not None:
            return {"status": "COMPLETED", "exit_code": code}
        if now - started >= timeout:
            return {"status": "TIMEOUT", "detail": f"Run reached its {timeout:g}s deadline."}
        if idle_timeout and now - last_activity >= idle_timeout:
            return {"status": "IDLE_TIMEOUT", "detail": f"No log activity for {idle_timeout:g}s."}
        if next_update is not None and now >= next_update:
            print(
                f"Runner active for {now - started:.0f}s; last log activity "
                f"{now - last_activity:.0f}s ago.", file=sys.stderr, flush=True,
            )
            next_update = now + heartbeat
        wait = min(0.5, timeout - (now - started))
        if idle_timeout:
            wait = min(wait, idle_timeout - (now - last_activity))
        try:
            process.wait(timeout=wait)
        except subprocess.TimeoutExpired:
            pass


def execute(command, cwd, run, timeout, *, idle_timeout=0, extra_logs=(),
            diagnose=None, heartbeat=0):
    started = time.monotonic()
    record = {
        "command": command, "cwd": str(cwd.resolve()), "timeout_seconds": timeout,
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "stdout": str(run / "stdout.log"), "stderr": str(run / "stderr.log"),
    }
    with (run / "stdout.log").open("wb") as stdout, (run / "stderr.log").open("wb") as stderr:
        try:
            process = subprocess.Popen(
                command, cwd=cwd, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                start_new_session=os.name == "posix",
            )
        except OSError as error:
            record.update(status="START_ERROR", error=str(error))
        else:
            try:
                if idle_timeout or diagnose or heartbeat:
                    logs = [run / "stdout.log", run / "stderr.log", *extra_logs]
                    record.update(watch(process, started, timeout, idle_timeout, logs, diagnose, heartbeat))
                else:
                    record.update(status="COMPLETED", exit_code=process.wait(timeout=timeout))
            except subprocess.TimeoutExpired:
                record.update(status="TIMEOUT")
            except KeyboardInterrupt:
                record.update(status="INTERRUPTED")
            except OSError as error:
                record.update(status="MONITOR_ERROR", detail=str(error))
            finally:
                if record.get("status") != "COMPLETED":
                    record["runner_reaped"] = stop(process)
                    record["exit_code"] = process.returncode
    record["finished_utc"] = datetime.now(timezone.utc).isoformat()
    record["duration_seconds"] = round(time.monotonic() - started, 3)
    write_json(run / "process.json", record)
    return record


def command_args(parser, args):
    if args.command and args.command[0] == "--":
        args.command.pop(0)
    if not args.command:
        parser.error("provide an executable and arguments after --")
    if not args.cwd.is_dir():
        parser.error("--cwd must be an existing directory")
    if args.timeout <= 0:
        parser.error("--timeout must be positive")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cwd", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command_args(parser, args)
    run = new_run(args.out)
    print(f"Evidence: {run}", flush=True)
    result = execute(args.command, args.cwd, run, args.timeout)
    print(json.dumps(result))
    if result["status"] != "COMPLETED":
        return 2
    return 0 if result["exit_code"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
