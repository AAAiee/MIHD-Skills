#!/usr/bin/env python3
"""Aggregate a review ledger. The script checks coverage, identity, and statuses."""

import argparse
import json
from pathlib import Path

STAGES = ("nunit", "standards", "workflow", "architecture", "design")
STATUSES = {"PASS", "FAIL", "BLOCKED", "NOT RUN", "N/A"}


def nonempty(value):
    return isinstance(value, str) and bool(value.strip())


def aggregate(ledger):
    if not isinstance(ledger, dict) or not nonempty(ledger.get("candidate")):
        raise ValueError("A candidate identity is required.")
    stages = ledger.get("stages")
    if not isinstance(stages, dict) or set(stages) != set(STAGES):
        raise ValueError("Record all five stage IDs, including N/A and NOT RUN.")
    statuses = {}
    invalid = []
    for name in STAGES:
        entry = stages[name]
        if not isinstance(entry, dict) or entry.get("status") not in STATUSES:
            raise ValueError(f"{name}: invalid status.")
        status = entry["status"]
        if status in {"N/A", "NOT RUN", "BLOCKED"} and not nonempty(entry.get("reason")):
            raise ValueError(f"{name}: give a reason for {status}.")
        if status in {"PASS", "FAIL"}:
            if entry.get("candidate") != ledger["candidate"] or not nonempty(entry.get("evidence")):
                invalid.append(name)
                status = "BLOCKED"
        statuses[name] = status
    if all(value == "N/A" for value in statuses.values()):
        raise ValueError("At least one stage must be in scope.")
    if "FAIL" in statuses.values():
        verdict = "FAIL"
    elif any(status in {"BLOCKED", "NOT RUN"} for status in statuses.values()):
        verdict = "INCOMPLETE"
    else:
        verdict = "PASS"
    return {"candidate": ledger["candidate"], "verdict": verdict, "stages": statuses,
            "stale_or_unreferenced_evidence": invalid}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("ledger", type=Path)
    args = parser.parse_args()
    try:
        result = aggregate(json.loads(args.ledger.read_text(encoding="utf-8")))
    except (OSError, ValueError, TypeError) as error:
        result = {"verdict": "INCOMPLETE", "reason": str(error)}
    print(json.dumps(result, indent=2))
    return {"PASS": 0, "FAIL": 1, "INCOMPLETE": 2}[result["verdict"]]


if __name__ == "__main__":
    raise SystemExit(main())
