# Review handoff and evidence

The coordinator gives each stage the same stable brief. A specialist invoked directly assembles the relevant parts itself.

- Review scope, candidate identity and base, reproducible diff or design paths, explicit exclusions, project rules, and requirements.
- What the user does, the inputs, expected outcomes and non-effects, and how to observe them.
- Applicable version, environment, authorized fixtures, the exact affected tests/checks when known, and current run evidence path. Give the design reviewer the render captures and the visual reference.
- Ownership and side effects allowed for this stage. Product and test edits require separate task scope. A live Unity session has one driver at a time.

Each stage returns: name, reviewed candidate, PASS / FAIL / BLOCKED / NOT RUN / N/A, evidence links, and findings. For a finding, identify the broken requirement or design concern, code location or image/step, effect on a real task, and a practical repair or deciding check. Distinguish confirmed failures from plausible risks and suggestions.

| Status | Meaning |
| --- | --- |
| PASS | Applicable checks ran on the reviewed state and support the stated claims. |
| FAIL | Valid evidence demonstrates a requirement or mandatory rule was violated. |
| BLOCKED | Required evidence is unavailable, invalid, or cannot be judged because a prerequisite or decision is missing. |
| NOT RUN | Applicable work was not attempted. |
| N/A | Out of scope with a specific reason. |

Overall FAIL if any applicable stage has a confirmed failure. Otherwise INCOMPLETE if any required stage or claim is blocked, unrun, or stale. Otherwise PASS for the stated scope. A stage may record several claim statuses and must surface any confirmed failure or remaining gap. Never average scores across stages. An advisory improvement does not become a requirement. Record required human design judgment separately and keep that claim open until the designated reviewer decides.

Keep a fresh result directory per invocation. Retain raw output and relevant logs, exact command/tool action, timestamp, code/version identity, selected tests or fixture, expected and actual values, and cleanup result. A static review can cite concrete code. A dynamic claim needs executed evidence. Revision IDs alone omit uncommitted changes. If a concurrent change invalidates a result, associate it with the older state and rerun before claiming a pass.

## Compute the verdict

Use the existing feature record for detailed findings. Store the minimal aggregation ledger in the run directory. Set candidate to the pinned identity from the brief. Use all five IDs. PASS and FAIL require the stage's candidate and a reference to the actual evidence. The evidence field can point to that stage's detailed report. N/A, NOT RUN, and BLOCKED require a reason. Example ledger:

~~~json
{
  "candidate": "reviewed-diff-identity",
  "stages": {
    "nunit": {"status": "PASS", "candidate": "reviewed-diff-identity", "evidence": "nunit/results.md"},
    "standards": {"status": "PASS", "candidate": "reviewed-diff-identity", "evidence": "standards/results.md"},
    "workflow": {"status": "N/A", "reason": "Approved scope is a pure formatting rule."},
    "architecture": {"status": "PASS", "candidate": "reviewed-diff-identity", "evidence": "architecture/results.md"},
    "design": {"status": "N/A", "reason": "No visible design or workflow changed."}
  }
}
~~~

Run [verdict.py](../scripts/verdict.py) with the ledger path and retain its JSON output. It calculates the verdict and downgrades stale or unreferenced stage results. The coordinator still verifies that referenced artifacts exist and support the reported claims. A script cannot authenticate a reviewer's assertions.
