# Choosing checks

Read this when allocating coverage or deciding where a test enters the system.

For NUnit case selection, fixtures, and assertions, use the [test design guide](../../review-nunit/references/test-design.md).

## Scope and mechanism are independent

Test scope describes how much real behavior is exercised. Runner/driver describes how it executes. NUnit can run small logic checks and substantial Unity integrations. MCP can run tests, invoke APIs, inspect state, or drive inputs if its server implements those capabilities. The protocol itself does not make a check end-to-end.

Use the smallest reliable check that exposes each failure, plus wider checks proving the pieces are connected. Overlap is useful when it catches different failures.

| Behavior/failure | Preferred automated check | Live workflow contribution |
| --- | --- | --- |
| Naming, snapping, filtering, sorting, validation, deterministic generation | NUnit over production rules; often EditMode without scene setup | UI supplies intended values and displays the result |
| Wrong objects edited, invalid/multi-object selection | EditMode with real objects, selection where relevant, and unselected sentinels | Active selection and Inspector/window state connect to the user action |
| Undo/Redo and grouping | EditMode through the real edit; inspect before/after/Undo/Redo | User gesture and normal Undo/Redo path produce the promised undo step |
| Scene/asset persistence and reference retention | EditMode with real saved/reopened assets/scenes and bookkeeping checks | User save/apply/reopen preserves the result |
| Prefab instance/source, overrides, nested/variant support | EditMode with the relevant real prefab forms | Inspector/Prefab Stage context and apply/revert controls work |
| Import/postprocess/generation | EditMode over source fixtures and actual outputs | Normal initiation, progress, errors, and output discoverability |
| Runtime previews, animation/physics, generated-content use | PlayMode with runtime consumers; target player for platform claims | The preview fits the actual editor task |
| Button binding, disabled states, focus, drag/drop, Scene handles | UI/input-capable driver with assertions; NUnit may host such a harness | This is the interaction evidence; backend calls cannot replace it |
| Layout, clipping, readable errors, feedback | Rendered UI evidence at supported sizes/scales with explicit criteria | Visual inspection and intended-user judgment when needed |
| Slow batches, repeated resource growth | Measured scenario with workload, environment, baseline/budget | Responsiveness, progress/cancel, and repeated-use symptoms |

Editor-only tools do not automatically need PlayMode or builds. Tools generating runtime content often need a consumption check even when their UI is editor-only. File existence does not establish usable runtime content.

## Seams in ordinary language

A **test boundary** is where a check supplies input and observes results: `BuildRenamePlan`, public `ApplyRename`, or the Apply button.

A **seam**, in Michael Feathers' original terminology, lets you vary behavior without editing the code where that behavior is used. A placement operation can accept a random-number source: production supplies randomness, a test supplies repeatable values. The parameter enables the substitution. Seams may be internal; they are not necessarily public C# interfaces or UI elements. See [Feathers' explanation](https://www.informit.com/articles/article.aspx?p=359417&seqNum=2).

Some TDD guides use “seam” loosely for a stable interface at which to test. Disambiguate it in the plan rather than forcing vocabulary onto the user.

Use existing operations first. Extract deterministic calculation when it isolates complex rules. Add substitution for actual needs such as time, random values, or unavailable external services. Do not wrap every class in an interface or mock Unity saving and then claim actual saving is verified.

## Example: batch rename

This is illustrative, not a contract to impose on another project. Suppose the agreed behavior is: rename selected objects `Prop_01`, `Prop_02` in a defined order; leave others unchanged; one Undo restores the batch; ordinary save/reopen preserves it.

1. **Logic:** ordered inputs yield the agreed names. Cover specified formatting, collision, invalid-input, and ordering rules with worked-out expected values.
2. **Integration:** create two selected objects and an unselected sentinel. Invoke the production operation. Assert new names and unchanged sentinel. Undo/Redo and check full restoration/reapplication. Check relevant dirty state, save through the supported workflow, reopen, reacquire, and check names/references.
3. **User journey:** open the real window, select fixtures through the required path, type the prefix, inspect preview, activate Apply, and inspect the hierarchy. Use ordinary Undo/Redo. Exercise a meaningful invalid/empty-selection state and window reopen if relevant.

An API probe invoking `ApplyRename` supports step 2, not step 3. A screenshot without the action cannot establish that Apply worked. Setting names directly during setup tests neither.

## Adverse cases follow the contract

Choose relevant risks and define expectations before testing:

- Bad input: empty/mixed selection, missing references, invalid values, unsupported assets, path/name collisions.
- Interrupted operation: cancel, exception, unavailable file/service. Establish atomic rollback versus partial success and user feedback.
- Repeated use: second invocation, Undo then reapply, selection/window/scene changes, repeated play transitions. Do not require idempotence for an operation meant to create another item.
- Data ownership: selected/unselected objects, instance/source prefab, generated/input assets, user fields that must survive.
- Scale/lifecycle: representative large batches, reload/recompilation, configured Enter Play Mode options, editor restart where relevant.

Cover important combinations, not every Cartesian product. Explain irrelevant dimensions. Code coverage can reveal unexercised code; it cannot establish correct requirements or a usable workflow.
