---
name: tdd
description: Build a feature or fix a bug test-first. Use when the user requests TDD, a failing test first, or a regression test as part of a fix. Drive one observable behavior at a time from a verified failure to a passing test.
---

# Test-driven development

## Choose the first behavior

Read the project guidance, relevant glossary and design decisions, existing tests, and actual runner. For a bug, identify the smallest reproduction and the expected outcome. For a feature, start with one observable behavior that exercises a real entry point. Record the behavior, test boundary, expected result and its source, and the plausible defect the test should expose.

Use an existing caller-facing boundary when it follows from the contract and nearby tests. Confirm a new public interface or ambiguous behavior from the approved design or with the user before writing the test. For Unity or C# NUnit work, read the [NUnit test design guide](../review-nunit/references/test-design.md) before choosing the fixture. It covers test boundaries, dependency seams, fakes, assertions, and when Unity itself must be involved.

## Gate implementation on red

1. **Pin the starting state.** Assign one coordinator to own the live project, runner, and evidence. When delegation is available, assign a test-author subagent only the contract, baseline, and test-patch task. Have it return a patch from outside the live project. The coordinator reviews the patch and applies it. With one agent, keep the same separate phases.
2. **Establish red.** Write a focused case or a small group for one behavior. Check actual failures on the starting behavior and the test-only patch. If a new entry point needs scaffolding to compile, keep that change explicit and limited to wiring that leaves the behavior absent. An already-passing case or an unrelated failure leaves red unproven. For NUnit, follow the [checkpoint procedure](references/checkpoint.md). For another framework, keep the same handoff and preserve fresh case-level evidence from the project runner.
3. **Hand off green.** After accepting the actual red failures, dispatch the implementation subagent with the frozen tests and failure evidence. In a single-agent session, begin production edits only at this point. Apply the smallest production change and rerun the same selection. For a legitimate test correction, return the corrected case to a clean red baseline and verify it before relying on green.
4. **Repeat from green.** Choose the next behavior using what the last slice taught you. Run relevant existing regressions in groups after related slices go green. Run broader suites when required by the project or the impact of the change. Perform in-scope cleanup as a separate pass from green and rerun the affected cases.

If the request is for the failing test alone, stop after verified red. In Unity, stage each coherent batch before publishing it to the Editor. Aim for one compile and reload window for the test batch and one for its implementation. Use a single end-to-end case first when the boundary is uncertain. Keep one Editor owner and use compile time for source review, fixture review, and selection preparation.

## When a durable test is impractical

First look for a narrower existing path that still exposes the failure. Use a faithful executable reproduction such as a small script or an owned Unity workflow when an NUnit test would need an unreliable or disproportionate harness. Capture the same observation before and after where feasible, and identify it as reproduction evidence. If the task requires a particular test-first proof and that proof is blocked, surface the blocker before changing the affected behavior.

## Report the evidence

Name the test or reproduction, its observed red failure, and the passing-after command and result when green is in scope. Include the revisions or relevant changes used for each run and the regressions run. State any missing evidence. Keep the evidence available for [review-nunit](../review-nunit/SKILL.md) when an independent review is requested.

