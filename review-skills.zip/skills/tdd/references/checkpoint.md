# NUnit checkpoints

Use [tdd_gate.py](../scripts/tdd_gate.py) with the [NUnit runner](../../review-nunit/references/runner.md). The coordinator owns the checkpoint and its evidence directory. A delegated test author prepares a patch in a scratch location and leaves the live project to the coordinator. If the host offers independent write permissions, keep the live project read-only for that worker. The checkpoint detects workspace drift visible to its inventory and gates the coordinator's handoff. Actual write restrictions come from the host.

## Prepare one batch

Use one behavior with an understood entry point and expected outcomes. Batch boundary cases and related inputs that can be designed against that contract. If a slice needs independent investigation to choose its boundary, prove one case first. Include Unity Edit Mode, Play Mode, or a player target when the behavior requires it. Use a separate checkpoint per selection and mode. Capture all relevant red results before editing production shared by those modes.

Choose a fresh evidence directory outside the worktree or inside an ignored folder outside Unity's imported folders. Before applying the test patch, record the starting workspace, including existing dirty files. If a new public entry point needs an inert signature or wiring, have the coordinator check and record that scaffolding separately before pinning the baseline. Make the test draft first and keep the promised behavior absent.

~~~bash
python3 /path/to/tdd/scripts/tdd_gate.py begin --root /path/to/worktree --state /path/to/evidence
~~~

The default inventory uses the Git worktree root, its current HEAD, and tracked and untracked changes Git reports. It hashes changed files and the declared test inputs. Git-ignored production inputs and changes made and reverted between checkpoints are outside that inventory. For other VCS or a project with additional inputs, pass `--inventory-command /path/to/inventory-argv.json` to `begin`. The file is a JSON argument array for a project-owned, read-only command run from the workspace root with a 30-second deadline. Its JSON output must have a reproducible base `revision` and `paths` containing all added, removed and modified workspace inputs, including pending changes and local edits outside a changelist. Use forward-slash paths relative to the root, and exclude evidence and generated outputs. Report blocked automated proof if the available inventory cannot establish the relevant starting state.

## Capture and accept red

Review and apply the complete test patch as a batch. Create a plan JSON file. List every changed test input, including test helpers, test data, and generated Unity metadata when applicable. Include unchanged fixtures or dependencies whose assertions and data must stay frozen. The coordinator verifies these are test inputs. List exact case names for the tests intended to fail. Cases that already pass on the starting behavior can be run as separate regression guards once the same candidate is loaded.

~~~json
{
  "test_files": ["Assets/Tests/SelectionTests.cs", "Assets/Tests/SelectionTests.cs.meta"],
  "cases": ["Tools.Tests.SelectionTests.Apply_LeavesUnselectedAssetUnchanged"],
  "runner": ["coplay", "--project", "/path/to/worktree", "--exclusive", "--test-platform", "EditMode"]
}
~~~

For other runners, use `unity` or `run` with the options from the [runner guide](../../review-nunit/references/runner.md). A project's existing standalone .NET runner is suitable for pure logic when it runs the same production code. With `run`, the project command must apply a matching filter and write NUnit 3 XML to `{xml}`. The checkpoint supplies evidence paths and expected names. If a wrapper hides its Unity project argument, provide `--unity-project` and confirm the wrapper actually uses that workspace. Use one Editor owner for live runs. Follow the [Coplay readiness procedure](../../review-nunit/references/coplay-live.md#overlap-audit-with-import-and-compile), confirm Unity loaded the actual candidate, and let it create any listed test metadata before invoking the checkpoint. During that compile, audit the patch and prepare the case selection.

~~~bash
python3 /path/to/tdd/scripts/tdd_gate.py red --state /path/to/evidence --plan /path/to/plan.json
~~~

`RED_NEEDS_REVIEW` means the runner supplied a specific failure for every selected case, on the recorded test patch. Inspect each diagnostic and relevant stack or fixture before accepting it. Confirm the assertion reaches the behavior and disagrees with the independently derived expectation. Build, setup, teardown, and unrelated failures leave red open. For a valid result, capture the connection between each failure and the contract in the reason.

~~~bash
python3 /path/to/tdd/scripts/tdd_gate.py accept-red --state /path/to/evidence --reason "The unselected sentinel name changed, violating the selection contract."
~~~

Dispatch the implementer only after `RED_VERIFIED`. If an infrastructure issue prevents a red result, diagnose the specific cause and retry on the same pinned workspace. If the evidence exists but the test is wrong, preserve it and use a fresh checkpoint based on the same pre-implementation state for the corrected test. A review after the feature was implemented can establish a regression test's value with an appropriate baseline. It is historical evidence, separate from proving this workflow ran test-first.

## Run green

Keep the test inputs and runner plan fixed. Check the implementation patch for changes to test files, discovery, or shared fixture inputs. Apply the production edits together. Reuse the reserved Editor and confirm it loaded the updated candidate. Run the checkpoint as follows.

~~~bash
python3 /path/to/tdd/scripts/tdd_gate.py green --state /path/to/evidence
~~~

The checkpoint reuses the red selection and runner. It rejects changed test inputs and records the passing candidate alongside the raw result. If a fixture needs a real correction, isolate or safely restore the pre-implementation state for the corrected red and use a new checkpoint. Keep concurrent user edits separate. Run nearby regressions against the loaded green candidate so they can share the same compilation.
