#!/usr/bin/env python3
"""Bind NUnit red and green evidence to a tests-first checkpoint."""

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import xml.etree.ElementTree as ET

RUNNER = Path(__file__).resolve().parents[2] / "review-nunit/scripts/nunit_gate.py"
sys.dont_write_bytecode = True
sys.path.insert(0, str(RUNNER.parent))
from unity_run import project_argument


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(path, data):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")


def output(command, root):
    return subprocess.run(command, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          check=True, timeout=30).stdout


def repo_path(root, name):
    path = Path(name)
    if not path.parts or path.is_absolute() or ".." in path.parts or path.as_posix() != name:
        raise ValueError(f"Expected a canonical project-relative path: {name!r}")
    absolute = root / path
    if absolute.parent.resolve() != absolute.parent:
        raise ValueError(f"Path uses a symlinked parent: {name!r}")
    return absolute


def fingerprint(path):
    try:
        mode = path.lstat().st_mode
    except FileNotFoundError:
        return None
    if stat.S_ISLNK(mode):
        return ["link", os.readlink(path)]
    if not stat.S_ISREG(mode):
        raise ValueError(f"Inventory path is not a file: {path}")
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return ["file", bool(mode & stat.S_IXUSR), digest.hexdigest()]


def snapshot(root, inventory, tests=()):
    if inventory is None:
        git = ["git", "--no-optional-locks"]
        if Path(os.fsdecode(output([*git, "rev-parse", "--show-toplevel"], root).rstrip(b"\n"))).resolve() != root:
            raise ValueError("--root must be the Git worktree root.")
        revision = output([*git, "rev-parse", "HEAD"], root).decode().strip()
        entries = output([*git, "status", "--porcelain=v1", "-z", "--untracked-files=all",
                          "--no-renames", "--ignore-submodules=none"], root).split(b"\0")
        if any(entry[:2] in (b"DD", b"AU", b"UD", b"UA", b"DU", b"AA", b"UU") for entry in entries):
            raise ValueError("Resolve conflicted paths before starting TDD.")
        names = [os.fsdecode(entry[3:]) for entry in entries if entry]
    else:
        data = json.loads(output(inventory, root))
        revision, names = data["revision"], data["paths"]
    if not isinstance(revision, str) or not revision or not isinstance(names, list):
        raise ValueError("Inventory must provide a revision and a list of changed paths.")
    return {
        "revision": revision,
        "changes": {name: fingerprint(repo_path(root, name)) for name in sorted(set(names))},
        "tests": {name: fingerprint(repo_path(root, name)) for name in tests},
    }


def require_test_files(state, names):
    for name in names:
        entry = state["tests"][name]
        if entry is None or entry[0] != "file":
            raise ValueError(f"Expected a regular test input file: {name}")


def case_failures(report, cases):
    """Inspect individual results. A failed suite or process alone cannot prove red."""
    folder = Path(report["evidence_directory"])
    xml = folder / "results.xml"
    if xml.is_file():
        run = ET.parse(xml).getroot()
        if run.tag != "test-run":
            raise ValueError("Expected a fresh NUnit 3 test run.")
        selected = list(run.iter("test-case"))
        names = Counter(case.get("fullname") for case in selected)
        failures = {}
        for case in selected:
            message = case.findtext("failure/message", "").strip()
            if (case.get("result") == "Failed" and case.get("site") in (None, "Test")
                    and case.get("label") in (None, "") and message):
                failures[case.get("fullname")] = message
    else:
        job = read_json(folder / "test-job.json")
        if job["job_id"] != report.get("job_id") or report.get("pending") or job["status"] != "failed":
            raise ValueError("Expected a reconciled, failed Coplay job.")
        selected = job["result"]["results"]
        names = Counter(case.get("fullName") for case in selected)
        failures = {}
        for case in selected:
            message = case.get("message")
            if case.get("state") == "Failed" and isinstance(message, str) and message.strip():
                failures[case["fullName"]] = message.strip()
    expected = Counter(cases)
    if names != expected:
        missing = list((expected - names).elements())
        extra = list((names - expected).elements())
        raise ValueError(f"Red selection mismatch. Missing cases: {missing}. Extra or duplicate cases: {extra}.")
    without_failure = sorted(set(cases) - failures.keys())
    if without_failure:
        raise ValueError(f"Red requires a test-body failure diagnostic for each case: {without_failure}.")
    return failures


def strings(values):
    return isinstance(values, list) and bool(values) and all(isinstance(v, str) and v.strip() for v in values)


def run_cases(args, plan, root):
    runner = plan["runner"]
    mode, *options = runner
    separator = options.index("--") if "--" in options else len(options)
    flags = {arg.split("=", 1)[0] for arg in options[:separator]}
    if flags & {"--out", "--expect", "--expect-file", "--whole-suite", "--probe-only",
                "--wait-ready", "--confirm-idle"}:
        raise ValueError("The TDD gate owns result paths and test selection.")
    selector = "--cwd" if mode == "run" else "--project"
    locations = {}
    for flag in (selector, "--unity-project"):
        if flag != selector and flag not in flags:
            continue
        values = [option.split("=", 1)[1] if "=" in option else options[index + 1]
                  for index, option in enumerate(options[:separator])
                  if option.split("=", 1)[0] == flag]
        if len(values) != 1:
            raise ValueError(f"Runner must select one location inside --root using {flag}.")
        locations[flag] = (root / values[0]).resolve()
        if not locations[flag].is_relative_to(root):
            raise ValueError(f"Runner location from {flag} is outside --root.")
    if mode == "run":
        unity_project = project_argument(options[separator + 1:], locations["--cwd"])
        if unity_project is not None and not unity_project.is_relative_to(root):
            raise ValueError("Runner location from -projectPath is outside --root.")
    command = [sys.executable, str(RUNNER), mode, "--out", str(args.state / "runs")]
    for name in plan["cases"]:
        command.extend(("--expect", name))
    result = subprocess.run([*command, *options], cwd=root, stdout=subprocess.PIPE, text=True)
    if result.returncode not in (0, 1, 2):
        raise ValueError(f"NUnit gate exited with code {result.returncode}.")
    return json.loads(result.stdout)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="step", required=True)
    for step in ("begin", "red", "accept-red", "green"):
        sub.add_parser(step).add_argument("--state", type=Path, required=True)
    sub.choices["begin"].add_argument("--root", type=Path, required=True)
    sub.choices["begin"].add_argument("--inventory-command", type=Path)
    sub.choices["red"].add_argument("--plan", type=Path, required=True)
    sub.choices["accept-red"].add_argument("--reason", required=True)
    args = parser.parse_args()
    args.state = args.state.resolve()
    baseline_file = args.state / "baseline.json"
    red_file = args.state / "red-review.json"
    accepted_file = args.state / "red-accepted.json"
    try:
        if args.step == "begin":
            root = args.root.resolve()
            inventory = read_json(args.inventory_command) if args.inventory_command else None
            if args.inventory_command and not strings(inventory):
                raise ValueError("Inventory command must be a nonempty JSON argument array.")
            if inventory is None and args.state.is_relative_to(root):
                probe = subprocess.run(["git", "--no-optional-locks", "check-ignore", "-q", "--",
                                        str(args.state) + os.sep], cwd=root, timeout=30)
                if probe.returncode != 0:
                    raise ValueError("Keep checkpoint evidence outside the worktree or under an ignored directory.")
            baseline = snapshot(root, inventory)
            args.state.mkdir(parents=True, exist_ok=True)
            save(baseline_file, {"root": str(root), "inventory": inventory, "snapshot": baseline})
            print("BASELINE_PINNED")
            return 0

        base = read_json(baseline_file)
        root = Path(base["root"])
        if args.step == "red":
            if red_file.exists():
                raise ValueError("A red result already exists. Use a new checkpoint for revised tests.")
            plan = read_json(args.plan)
        else:
            red = read_json(red_file)
            plan = red["plan"]
        cases, tests, runner = (plan[key] for key in ("cases", "test_files", "runner"))
        if (not all(strings(values) for values in (cases, tests, runner))
                or len(set(cases)) != len(cases) or len(set(tests)) != len(tests)
                or runner[0] not in ("run", "unity", "coplay")):
            raise ValueError("Plan needs unique test cases, unique test input files, and a supported runner.")
        before = snapshot(root, base["inventory"], tests)
        require_test_files(before, tests)
        if before["revision"] != base["snapshot"]["revision"]:
            raise ValueError("The base revision changed. Start a new checkpoint.")

        if args.step == "accept-red":
            if before != red["snapshot"] or not args.reason.strip():
                raise ValueError("Red approval requires the reviewed snapshot and a concrete reason.")
            save(accepted_file, {"reason": args.reason, "red_record": fingerprint(red_file)})
            print("RED_VERIFIED")
            return 0
        if args.step == "red":
            old, current = base["snapshot"]["changes"], before["changes"]
            absent = object()
            outside = [name for name in sorted(old.keys() | current.keys())
                       if old.get(name, absent) != current.get(name, absent) and name not in tests]
            if outside:
                raise ValueError(f"Outside the approved test patch: {', '.join(outside)}")
        else:
            if read_json(accepted_file)["red_record"] != fingerprint(red_file):
                raise ValueError("The approved red record changed.")
            if before["tests"] != red["snapshot"]["tests"]:
                raise ValueError("Frozen test inputs changed. Reestablish red before proceeding.")
        report = run_cases(args, plan, root)
        if snapshot(root, base["inventory"], tests) != before:
            raise ValueError("The workspace changed during the run. Inspect the saved evidence before retrying.")
        if args.step == "red":
            if report.get("status") != "TEST_FAILURE":
                raise ValueError(f"Runner did not establish a failed run: {report.get('reason')}")
            failures = case_failures(report, cases)
            save(red_file, {"plan": plan, "snapshot": before, "runner": report, "failures": failures})
            print(json.dumps({"status": "RED_NEEDS_REVIEW", "failures": failures,
                              "evidence": report["evidence_directory"]}, indent=2))
        else:
            if report.get("status") != "PASS":
                raise ValueError(f"Green requires a passing run: {report.get('reason')}")
            if runner[0] != "coplay" and report["counts"]["Passed"] != len(cases):
                raise ValueError("Green ran additional cases. Use the frozen selection.")
            evidence = Path(report["evidence_directory"])
            record = {"status": "GREEN_VERIFIED", "evidence": str(evidence)}
            save(evidence / "green-checkpoint.json", {**record, "snapshot": before})
            print(json.dumps(record, indent=2))
        return 0
    except (OSError, ValueError, KeyError, IndexError, TypeError, subprocess.SubprocessError, ET.ParseError) as error:
        print(f"TDD checkpoint blocked: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
